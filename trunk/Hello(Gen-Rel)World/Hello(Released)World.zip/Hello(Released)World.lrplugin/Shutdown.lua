--[[
        Shutdown.lua
        
        Generic shutdown module.
        
        Just sets shutdown flag, which often is enough.
        
        May be copied, but will not be customized by plugin generator.
--]]

_G.shutdown = true


