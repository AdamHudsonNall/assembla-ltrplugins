--[[
        Reload.lua (plugin)
--]]

reload:now() -- instruct global reloader to do it now, without hesitation or prompting...
