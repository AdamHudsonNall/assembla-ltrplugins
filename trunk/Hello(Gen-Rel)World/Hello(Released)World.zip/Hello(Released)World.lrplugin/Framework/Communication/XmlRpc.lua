--[[
        XmlRpc.lua
        
        Depends on LrXml.
--]]

local XmlRpc, dbg = Object:newClass{ className = 'XmlRpc' }



--- Constructor for extending class.
--
function XmlRpc:newClass( t )
    return Object.newClass( self, t )
end



--- Constructor for new instance.
--
--  @param      t       parameter table may include url, or it may be supplied later.
--
function XmlRpc:new( t )
    local o = Object.new( self, t )
    if o.url then
    else
        error( "XmlRpc needs URL" )
    end    
    return o
end



--  Initializer for submission URL, in case not known at construction time.
--
--  @param      t       parameter table to include url.
--
function XmlRpc:_init( t )
    self.url = t.url
end



--- Send specified request and return reply.
--
--  @param      name        Method name, may be in dot notation, or simple.
--  @param      params      Parameter table containing, for each parameter:<ul>
--                              <li>value
--                              <li>type</ul>
--  @param      timeout     response timeout defaults to 10 seconds.
--
--  @usage      Implements spec defined at http://www.xmlrpc.com/spec, 6/30/2003 update.
--
--  @usage      throws error if not valid xml-rpc reply, or any other problems ensue in getting a proper response.
--              <br>Note: Does not throw error upon remote procedure fault - as long as the reply properly indicates a fault...
--
--  @usage      Must be called from an asynchronous task, wrapped. (not wrapped from within).
--
--  @return     status  (boolean) true iff successful call, meaning correctly forumulated response, with real parameters instead of fault struct.
--              <br>false iff remote procedure fault.
--  @return     xml-dom-instance containing entire reply, but only after a few preliminary integrity checks.
--  @return     (table) response parameter elements:<ul>
--              <li>type (see xml-rpc spec)
--              <li>value</ul>OR (if fault)<ul>
--              <li>faultCode
--              <li>faultString</ul>
--
function XmlRpc:sendAndReceive( name, params, timeout )

    assert( self.url, "Missing XmlRpc Url..." )
    if not timeout then
        timeout = 10
    end
    
    local bldr = LrXml.createXmlBuilder( false ) -- false => include decl.
    bldr:beginBlock( "methodCall" )
    bldr:tag( "methodName", name ) -- no attrs
    if params and #params > 0 then
        bldr:beginBlock( "params" )
        for i,v in ipairs( params ) do
            bldr:beginBlock( "param" )
            bldr:beginBlock( "value" )
            bldr:tag( v.type, v.value )
            bldr:endBlock()
            bldr:endBlock()
        end
        bldr:endBlock()
    end 
    bldr:endBlock()
    
    local xmlReq = bldr:serialize()
    
    -- dbg( "req: ", xmlReq )
    
    local reqHdrs = {}
    reqHdrs[#reqHdrs + 1] = { field='Content-Length', value='' .. xmlReq:len() }

    local body, hdrs = LrHttp.post( self.url, xmlReq, reqHdrs, "POST", timeout )

    -- dbg( "hdrs: ", #hdrs )
    
    if hdrs.status then
        if hdrs.status ~= 200 then
            error( "Server response status: " .. hdrs.status )
        end
    else
        error( "Missing response status." )
    end
    
    local start, stop = body:find( '<?xml', 1, true )
    if start then
        body = body:sub( start )
        dbg( "body: ", body )
    else
        error( "Spec requires xml declaration in response: " .. body:sub( 1, 100 ) )
    end
    
    local xml = LrXml.parseXml( body ) -- xml IS root node.
    if not xml then
        error( "Invalid response from " .. self.url .. " - unparsable xml." )
    end
    
    dbg( "root: ", xml:name() )
    if xml:name() ~= 'methodResponse' then
        error( "Invalid xml response from " .. self.url .. " - root node not method-response, is: " .. xml:name() )
    end
    
    local paramNode = xml:childAtIndex( 1 ) 
    if not paramNode then
        error( "Invalid xml response from " .. self.url .. " - no param node." )
    end

    -- note: this implementation requires at least a one-parameter response from the server.
    -- I dunno if the spec also thinks thats a good idea, but I sure do...
    if paramNode:name() == 'params' then

        local values = {}
        local i = 1
        for param in self:_params( xml ) do
            -- dbg( "param type: ", param.type )
            -- dbg( "param value: ", param.value )
            values[i] = { type = param.type, value = param.value }
            i = i + 1
        end

        return true, xml, values
        
    elseif paramNode:name() == 'fault' then -- calling context decodes fault response.
    
        local faultStruct = self:_getFaultStruct( xml )
        return false, xml, faultStruct
        
    else
        error( "Invalid xml response from " .. self.url .. " - param node not recognized: " .. paramNode:name() )
    end
    
end



--  Iterate response parameters, given original xml response.
--
--  @usage      for param in xmlRpc:params( xmlResponse ) do
--              <br>    process param.value of param.type...
--
function XmlRpc:_params( xml )

    local index = 0
    local params = xml:childAtIndex( 1 )
    local max = params:childCount()
    
    return function()
        index = index + 1
        if index > max then
            return nil
        end
        local node = params:childAtIndex( index )
        if node then -- param node
            local valueNode = node:childAtIndex( 1 ) -- value node
            if valueNode:name() == 'value' then
                local typeNode = valueNode:childAtIndex( 1 )
                return { type = typeNode:name(), value = typeNode:text() }
            else
                error( "Invalid value node name." )
            end
        else
            error( "No param node." )
        end
    end

end



--  Iterate response parameters, given original xml response.
--
--  @param      xml     (xmlDomInstance) original xml response.
--
--  @return     (table) { faultCode=..., faultString=... }
--
function XmlRpc:_getFaultStruct( xml )

    local fault = xml:childAtIndex( 1 ) -- xml is method-response (root).
    local struct = {}
    
    local valueNode = fault:childAtIndex( 1 )
    if valueNode then -- value node
        local structNode = valueNode:childAtIndex( 1 )
        if structNode:name() == 'struct' then
            local memberNode = structNode:childAtIndex( 1 )
            if memberNode:name() == 'member' then
                local nameNode = memberNode:childAtIndex( 1 )
                if nameNode:name() == 'name' then
                    if nameNode:text() == 'faultCode' then
                        local valueNode = memberNode:childAtIndex( 2 ):childAtIndex( 1 ) -- skipping over the type.
                        if valueNode then
                            local faultCode = num:numberFromString( valueNode:text() )
                            if faultCode then
                                struct.faultCode = faultCode
                            else
                                error( "No fault code" )
                            end
                        else
                            error( "No fault code value node" )
                        end
                    else
                        error( "No fault code name node" )
                    end
                else
                    error( "bogus fault code name" )
                end
            else
                error( "no fault code member" )
            end
            
            memberNode = structNode:childAtIndex( 2 )
            if memberNode:name() == 'member' then
                local nameNode = memberNode:childAtIndex( 1 )
                if nameNode:name() == 'name' then
                    if nameNode:text() == 'faultString' then
                        local valueNode = memberNode:childAtIndex( 2 ):childAtIndex( 1 ) -- skipping over the type.
                        if valueNode then
                            local faultString = valueNode:text()
                            if str:is( faultString ) then
                                struct.faultString = faultString
                            else
                                error( "No fault string" )
                            end
                        else
                            error( "No fault string value node" )
                        end
                    else
                        error( "No fault string name node" )
                    end
                else
                    error( "bogus fault string name" )
                end
            else
                error( "no fault string member" )
            end
            
        else
            error( "no fault struct" )
        end
    else
        error( "no fault value node" )
    end

    return struct                        

end



return XmlRpc