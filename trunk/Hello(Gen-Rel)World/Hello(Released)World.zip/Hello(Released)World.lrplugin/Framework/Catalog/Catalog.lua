--[[
        Catalog.lua
--]]

local Catalog, dbg = Object:newClass{ className = 'Catalog' }



--- Constructor for extending class.
--
function Catalog:newClass( t )
    return Object.newClass( self, t )
end



--- Constructor for new instance.
--
function Catalog:new( t )
    local o = Object.new( self, t )
    return o
end



--- Catalog access wrapper that distinquishes catalog contention errors from target function errors.
--
--  @param              tryCount        Number of tries before giving up, at a half second per try (average).
--  @param              func            Catalog with-do function.
--  @param              catalog             The lr-catalog object.
--  @param              p1              First parameter which may be a function, an action name, or a param table.
--  @param              p2              Second parameter which will be a function or nil.
--      
--  @usage              Returns immediately upon target function error. 
--  @usage              The purpose of this function is so multiple concurrent tasks can access the catalog in succession without error.
--                          
--  @return             status (boolean):    true iff target function executed without error.
--  @return             other:    function return value, or error message.
--
function Catalog:withDo( tryCount, func, catalog, p1, p2 )
    while( true ) do
        for i = 1, tryCount do
            local sts, qual = LrTasks.pcall( func, catalog, p1, p2 )
            if sts then
                return true, qual
            elseif str:is( qual ) then
                local found = qual:find( "LrCatalog:with", 1, true ) or 0 -- return position or zero, instead of position or nil.
                if found == 1 then -- problem reported by with-catalog-do method.
                    local found2 = qual:find( "already inside", 15, true )
                    if found2 then
                        -- problem is due to catalog access contention.
                        dbg( 'catalog contention: ' .. str:to( qual ) )
                        if app:isVerbose() then -- log verbose - user app-wide debug mode
                            app:logWarning( 'catalog contention: ' .. str:to( qual ) )
                            LrTasks.sleep( math.random( .1, 1 ) ) -- sleep for a half-second or so, then try again.
                        else
                            LrTasks.sleep( math.random( .1, 1 ) ) -- sleep for a half-second or so, then try again.
                        end
                    else
                        return false, qual
                    end
                else
                    return false, qual
                end
            else
                return false, 'Unknown error occurred accessing catalog.'
            end
        end
    	local action = app:showWarning( "Unable to access catalog.", "Keep Trying", "Give Up" )
    	if action == 'ok' then
    		-- keep trying
    	else
    		-- assert( action == 'cancel', "unexpected error action: " .. str:to( action )  )
    		return false, "Gave up trying to access catalog."
    	end
    end
    return false, str:format( "Unable to access catalog." )
end



--- select one photo, de-select all others.
--
function Catalog:selectOnePhoto( photo )
    catalog:setSelectedPhotos( photo, { photo } )
end



--- Get selected photos.
--
--  @usage Use instead of getTargetPhotos if you don't want the entire filmstrip to be returned when nothing is selected.
--
--  @return empty table if none selected - never returns nil.
--
function Catalog:getSelectedPhotos()
    local photo = catalog:getTargetPhoto()
    if not photo then
        return {}
    else
        return catalog:getTargetPhotos()
    end
end
    


--  Rave metadata for selected photos.
--
--  @param              photos - photos to save metadata for, or nil to do all target photos.
--  @param              includeVirtualCopies: true to include, false to ignore.
--  @param              warnAboutVirtualCopies: 0 => no warning, 1 => log-warning, 2 => log-error.
--
--  @usage              Switch to grid mode first if desired, and pre-select target photos.
--  @usage              Ignores photos that are set to read-only, so make read-write before calling, if desired.
--
--  @usage              Uses keystroke emission to do the job.
--  @usage              User will be prompted to first make sure the "Overwrite Settings" prompt will no longer appear.
--
--  @return             Array of photos whose metadata has been saved.
--  @return             Error message if unable to save metadata.
--
function Catalog:___raveMetadata( photos, includeVirtualCopies, warnAboutVirtualCopies, scope )

                            if not photos then
                                photos = catalog.getTargetPhotos()
                            end
                            local savedPhotos = {}
                            
                            if #photos < 1 then
                                return false, "Nothing is selected." -- actually means nothing in filmstrip.
                            end
                            
                            local errMsg = "Unknown"
                            
                            local time = LrDate.currentTime()
                        
                            local s, m
                            if WIN_ENV then
                                s, m = app:sendWinAhkKeys( "{Ctrl Down}s{Ctrl Up}" ) -- include post keystroke yield.
                            else
                                s, m = app:sendMacEncKeys( "Cmd-s" )
                            end
                            
                            local saved = false
                            -- loop until all photos have xmp data that is consistent with last edit time - indicating all are saved.
                            local nNotSaved
                            local nSaved
                            local timeout = time * (#photos * .1) + 1 -- should not take more than 100ms per photo.
                            local pass = 1
                            
                            repeat -- keep trying
                                
                                nNotSaved = 0
                                nSaved = 0
                                
                                for i, photo in ipairs( photos ) do
                        
                                    if scope then
                                        scope:setPortionComplete( i, #photos )
                                    end
                                
                                    repeat -- do one
                                    
                                        local photoPath = photo:getRawMetadata( 'path' )
                                        local form = photo:getRawMetadata( 'fileFormat' )
                                        local virt = photo:getRawMetadata( 'isVirtualCopy' )
                                        if virt then
                                            if includeVirtualCopies then
                                                nSaved = nSaved + 1
                                                savedPhotos[#savedPhotos + 1] = photo
                                            end
                                            if warnAboutVirtualCopies == 0 then
                                                --
                                            elseif warnAboutVirtualCopies == 1 then
                                                app:logWarning( str:fmt( "Virtual copies not yet supported, ignored ^1 (^2)", photoPath, photo:getFormattedMetadata( 'copyName' ) ) ) 
                                            elseif warnAboutVirtualCopies == 2 then
                                                app:logError( str:fmt( "Virtual copies not yet supported, ignored ^1 (^2)", photoPath, photo:getFormattedMetadata( 'copyName' ) ) ) 
                                            end
                                            break
                                        end
                                        -- fall-through => real photo.
                                        local targ
                                        if form == 'RAW' then
                                            targ = LrPathUtils.replaceExtension( photoPath, "xmp" )
                                        elseif form == 'VIDEO' then
                                            app:logInfo( "Video file ignored: " .. photoPath )
                                            break
                                        else -- includes DNG.
                                            targ = photoPath
                                        end
                                        
                                        local time2 = LrFileUtils.fileAttributes( targ ).fileModificationDate
                                        if time2 == nil then
                                            app:logWarning( "File not found: " .. targ ) -- the only reason not to be able to get attribute is if file not found.
                                            break
                                        end
                                        
                                        local s, m = fso:isReadOnly( targ )
                                        if s then
                                            app:logWarning( str:fmt( "Can not save metadata for ^1 - its xmp is read-only.", photoPath ) )
                                            break
                                        elseif m then
                                            app:logWarning( str:fmt( "Can not ascertain if xmp is read-only - skipping ^1", photoPath ) )
                                            break
                                        -- else good to go
                                        end
                                        
                                        if time2 >= time then
                                            nSaved = nSaved + 1
                                            savedPhotos[#savedPhotos + 1] = photo
                                            app:logInfo( "Metadata save validated: " .. photoPath )
                                        elseif fso:existsAsFile( photoPath ) then
                                            nNotSaved = nNotSaved + 1
                                            app:logInfo( str:fmt( "Metadata save not validated yet: ^1, time1: ^2, time2: ^3", photoPath, time, time2 ) )
                                        else
                                            -- keep going until timeout.
                                            app:logWarning( str:fmt( "Metadata not saved, file non-existent: ^1", photoPath ) )
                                        end                
                                    
                                    until true
                                    
                                    if scope then
                                        if scope:isCanceled() then
                                            return nil, 'Canceled'
                                        end
                                    end
                                
                                end
                                
                                if nNotSaved == 0 then
                                    saved = true
                                    break
                                elseif LrDate.currentTime() > timeout then
                                    errMsg = "Timeout - some metadata not saved."
                                    break
                                else
                                    if #photos > 1 then
                        
                                        if pass == 1 then
                        
                                            local m = {}
                                            m[#m+1] = "This plugin needs to make sure all metadata has been saved (from catalog to xmp)."
                                            m[#m+1] = "To do this it must ensure the 'Overwrite Settings' prompt is not getting in the say."
                                            m[#m+1] = "If the aforementioned prompt is being displayed in a dialog box (you won't be able to reach it just yet), then answer the aforementioned prompt including checking of the 'Don't show again box' - you must choose 'Overwrite Settings'. Then invoke the same plugin function again."
                                            --[[local answer = dialog:isOk( table.concat( m, "\n\n" ), "SaveMetaPrompt" )
                                            if answer then
                                                timeout = LrDate.currentTime() * (#photos * .1) + 1                    
                                            else
                                                errMsg = "User canceled."
                                                break
                                            end--]]
                                            dialog:showInfo( table.concat( m, "\n\n" ) )
                                            pass = pass + 1
                                            -- go again
                                        else
                                            break
                                        end
                                
                                    else
                                        -- try the photo again until timeout or success...
                                    end
                                end
                            
                            until saved -- or break without save validation.
                        
                            if nSaved > 0 then
                                return savedPhotos
                            else
                                return nil, errMsg
                            end
                        
end



--- Save metadata for selected photos.
--
--  @param              photo - single photo object to save metadata for.
--  @param              photoPath - photo path.
--  @param              alreadyInLibraryModule - true iff library module has been assured before calling.
--  @param              service - if a scope in here it will be used for captioning.
--
--  @usage              Library mode is not necessary to save single photo metadata.
--  @usage              *** Side-effect of single photo selection - be sure to save previous multi-photo selection to restore afterward if necessary.
--  @usage              Will cause metadata conflict flag if xmp is read-only, so make read-write before calling, if desired.
--  @usage              Uses keystroke emission to do the job.
--
--  @return             true iff metadata saved.
--  @return             error message if metadata not saved.
--
function Catalog:savePhotoMetadata( photo, photoPath, targ, service )

    if not photoPath then
        error( "need photo-path" )
    end
    
    if not targ then
        error( "need targ" )
    end
    
    -- Side effect: selection of single photo to be saved.
    cat:selectOnePhoto( photo ) -- make sure only one photo is targeted by ctrl-s.
    
    local time
    local s, m
    if WIN_ENV then
        if service and service.scope then
            service.scope:setCaption( str:fmt( "Waiting for 'Save Metadata' confirmation..." ) ) -- only visible after the save metadata operation is complete.
        end
        time = LrDate.currentTime() -- windows file times are high-precision and haven't needed a fudge factor so far. ###1 watch for metadata timeout on Windows too.
        s, m = app:sendWinAhkKeys( "{Ctrl Down}s{Ctrl Up}" ) -- Save metadata - for one photo: seems reliable enough so not using the catalog function which includes a prompt.
    else -- mac-env
        time = math.floor( LrDate.currentTime() ) -- file-attrs seem to be nearest second on Mac - make sure this does not appear to be in the future.
        s, m = app:sendMacEncKeys( "Cmd-s" )
    end
    if s then
        app:logInfo( str:fmt( "Issued command to save metadata for ^1", photoPath ), App.verbose ) -- just log final results in normal case.
    else
        return false, str:fmt( "Unable to save metadata for ^1 because ^2", photoPath, m )
    end
    local time2 = LrFileUtils.fileAttributes( targ ).fileModificationDate
    local count = 50 -- give 5 seconds or so for the metadata save to settle, in case Lr is constipated on this machine, or some other process is interfering temporarily...
    while count > 0 and (time2 ~= nil and time2 < time) do
        LrTasks.sleep( .1 )
        count = count - 1
        time2 = LrFileUtils.fileAttributes( targ ).fileModificationDate
    end
    if time2 ~= nil and time2 >= time then
        return true
    elseif time2 == nil then
        return false, str:fmt( "Unable to save metadata for ^1 because save validation timed out, unable to get xmp file time.", photoPath ) -- see edit of this on mac ###1
    else
        return false, str:fmt( "Unable to save metadata for ^1 because save validation timed out, xmp file time: ^2, save metadata command time: ^3.", photoPath, time2, time )
    end
    
end



--- Save metadata for selected photos.
--
--  @param              photos - photos to save metadata for, or nil to do all target photos.
--  @param              preSelect - true to have specified photos selected before saving metadata, false if you are certain they are already selected.
--  @param              restoreSelect - true to have previously photo selections restored before returning.
--  @param              service - if a scope in here it will be used for captioning.
--
--  @usage              Switch to grid mode first if desired, and select target photos first if possible.
--  @usage              Cause metadata conflict for photos that are set to read-only, so make read-write before calling, if desired.
--  @usage              Uses keystroke emission to do the job.
--  @usage              User will be prompted to first make sure the "Overwrite Settings" prompt will no longer appear.
--
--  @return             true iff metadata saved.
--  @return             error message if metadata not saved.
--
function Catalog:saveMetadata( photos, preSelect, restoreSelect, alreadyInGridMode, service )

    if not photos then
        error( "specify photos to save-metadata" )
    end
    
    if #photos < 1 then
        error( "check photo count before calling save-metadata" )
    end

    local selPhotos = self:saveSelPhotos()

    if preSelect then
        local photoToBe
        if selPhotos.mostSelPhoto then
            for i, photo in ipairs( photos ) do
                if photo == selPhotos.mostSelPhoto then
                    photoToBe = photo
                    break
                end
            end
        end
        if not photoToBe then
            photoToBe = photos[1]
        end
        catalog:setSelectedPhotos( photoToBe, photos ) -- make sure the photos to have their metadata saved are the ones selected.
    end

    local status = false
    local message = "unknown"
    
    if not alreadyInGridMode then    
        app:sendKeys( 'g' ) -- attempt to put in grid mode, but dont prompt.
    end

    
    if service and service.scope then
        service.scope:setCaption( str:fmt( "Waiting for 'Save Metadata' button click..." ) ) -- only visible after the save metadata operation is complete.
    end
    -- Note: this prompt is optional, but the confirmation prompt is not:
    local m = {}
    m[#m + 1] = "Metadata must be saved to ensure this operation is successful."
    m[#m + 1] = "After you click 'Save Metadata', you should see an extra \"Operation\" pop up in the upper left corner of Lightroom's main window - be looking for it... (if no other operations are in progress, it will say 'Saving Metadata')"
    m[#m + 1] = "If you are in grid mode, and there are no other dialog boxes open, then click 'Save Metadata' to begin. If there are other Lightroom/plugin dialog boxes open, the click 'Let Me Close Dialogs' and do so (close them). If you are not in grid mode, or cant get the dialog boxes to stay closed, then you must click 'Cancel', and try again after remedying..."
    m[#m + 1] = "Click 'Save Metadata' when ready."
    m = table.concat( m, '\n\n' )

    local answer
    repeat
        answer = dialog:showInfo( m, "SaveMetadataPrompt", {{label='Save Metadata',verb='ok'},{label="Let Me Close Dialogs",verb='other'}} )
        
        if answer == 'other' then
            LrTasks.sleep( 3 )
        else
            break
        end
    until false
    repeat
        if answer == 'ok' then
            if service and service.scope then
                service.scope:setCaption( str:fmt( "Waiting for 'Save Metadata' confirmation..." ) ) -- only visible after the save metadata operation is complete.
            end
            if WIN_ENV then
                status, message = app:sendWinAhkKeys( "{Ctrl Down}s{Ctrl Up}" ) -- include post keystroke yield.
            else
                status, message = app:sendMacEncKeys( "Cmd-s" )
            end
            if status then
                --
            else
                break
            end
            --local m = "Has the 'Save Metadata' operation completed?\n \nYou can tell by the upper left-hand corner of the main Lightroom window: the 'Save Metadata' operation that was started there will disappear when the operation has completed."
            local m = "Wait for the 'Save Metadata' operation to complete, then click 'Save Metadata is Complete'.\n \nYou can tell when its complete by looking in the upper left-hand corner of the main Lightroom window: it will say \"Waiting for 'Save Metadata' confirmation...\" when the operation has completed."
            local answer2 = dialog:showInfo( m, nil, 'Save Metadata is Complete', 'Save Metadata Never Started' )
            if answer2 == 'ok' then -- yes
                status = true
            elseif answer2 == 'cancel' then -- no
                status, message = false, "Apparently, metadata was not saved - most often caused by dialog box interference. Try to eliminate interfereing dialog boxes, then attempt again..."
            elseif answer2 == 'other' then -- dunno
                status, message = nil, "Metadata must be saved. Hint: to tell if it gets saved, watch the progress indicator in the upper left-hand corner of the main Lightroom window."
            end
        elseif not answer or answer == 'cancel' then -- answer is coming back false for cancel - doc says cancel => nil for prompt-for-action-with-do-not-show...
            -- 'cancel' is returned by other lr-dialog methods, so test for it left in here as cheap insurance / reminder...
            status, message = nil, "User canceled."
        else
            error( "invalid answer: " .. str:to( answer ) )
        end
    until true
    
    if restoreSelect then
        cat:restoreSelPhotos( selPhotos )
    end
    return status, message

end



--- Read metadata for selected photos.
--
--  @param              photo - single photo object to read metadata for.
--  @param              photoPath - photo path.
--  @param              alreadyInLibraryModule - true iff library module has been assured before calling.
--  @param              service - if a scope in here it will be used for captioning.
--
--  @usage              Not reliable in a loop without user prompting in between (or maybe lengthy delays).
--  @usage              Switch to grid mode first if necessary.
--  @usage              *** Side-effect of single photo selection - be sure to read previous multi-photo selection to restore afterward if necessary.
--  @usage              Ignores photos that are set to read-only, so make read-write before calling, if desired.
--  @usage              Uses keystroke emission to do the job.
--
--  @return             true iff metadata readd.
--  @return             error message if metadata not readd.
--
function Catalog:readPhotoMetadata( photo, photoPath, alreadyInLibraryModule, service )

    if not photoPath then
        error( "need photo-path" )
    end
    
    if MAC_ENV then
        error( "Read Metadata not supported on Mac (programmatically)")
    end
    
    -- Side effect: selection of single photo to be read.
    cat:selectOnePhoto( photo ) -- make sure only one photo is targeted by keystroke.
    
    local time
    if WIN_ENV then
        if service and service.scope then
            service.scope:setCaption( str:fmt( "Waiting for 'Read Metadata' confirmation..." ) ) -- only visible after the save metadata operation is complete.
        end
        
        -- must be as sure as possible we're in library module, view mode does not matter.
        if not alreadyInLibraryModule then
            local s, m = gui:switchModule( 1 )
            if s then
                app:logInfo( str:fmt( "Issued command to switch to library module for ^1", photoPath ), App.verbose ) -- just log final results in normal case.
            else
                return false, str:fmt( "Unable to switch to library module for ^1 because ^2", photoPath, m )
            end
        end
        time = LrDate.currentTime() -- windows file times are high-precision and haven't needed a fudge factor so far.
        local s, m = app:sendWinAhkKeys( "{Alt Down}mr{Alt Up}" ) -- Read metadata - for one photo: seems reliable enough so not using the catalog function which includes a prompt.
        if s then
            app:logInfo( str:fmt( "Issued command to read metadata for ^1", photoPath ), App.verbose ) -- just log final results in normal case.
        else
            return false, str:fmt( "Unable to read metadata for ^1 because ^2", photoPath, m )
        end
    end
    
    -- fall-through => one photo selected in library, and command issued to read metadata.
    
    local time2 = photo:getRawMetadata( 'lastEditTime' )
    local count = 50 -- give 5 seconds or so for the metadata read to settle, in case Lr is constipated on this machine, or some other process is interfering temporarily...
    while count > 0 and (time2 ~= nil and time2 < time) do -- see if possible to not have a fudge factor here. ###1
        LrTasks.sleep( .1 )
        count = count - 1
        time2 = photo:getRawMetadata( 'lastEditTime' )
    end
    if time2 ~= nil and time2 >= time then
        return true
    elseif time2 == nil then
        return false, str:fmt( "Unable to read metadata for ^1 because read validation timed out (never got a read on last-edit-time).", photoPath )
    else
        return false, str:fmt( "Unable to read metadata for ^1 because read validation timed out (last-edit-time never updated).", photoPath )
    end
end



--  Read metadata for selected photos.
--
--  @param              photos - photos to save metadata for, or nil to do all target photos.
--  @param              preSelect - true to have specified photos selected before reading metadata, false if you are certain they are already selected.
--  @param              restoreSelect - true to have previously photo selections restored before returning.
--  @param              service - if a scope in here it will be used for captioning.
--
--  @usage              Only supported on Windows platform - if called in Mac environment it will throw an error.
--  @usage              Switch to grid mode first if desired, and pre-select target photos.
--  @usage              Uses keystroke emission to do the job.
--  @usage              Includes optional user pre-prompt (before issuing read-metadata keys), and mandatory user post-prompt (to confirm metadata read).
--
--  @return             true iff metadata saved.
--  @return             error message if metadata not read.
--
function Catalog:readMetadata( photos, preSelect, restoreSelect, alreadyInGridMode, service )

    if not photos then
        error( "read-metadata requires photos" )
    end
    
    if #photos < 1 then
        error( "check photo count before calling read-metadata" )
    end
    
    if MAC_ENV then
        error( "Plugins cant 'Read Metadata' on Mac." )
    end
    
    local selPhotos = self:saveSelPhotos()

    if preSelect then
        local photoToBe
        if selPhotos.mostSelPhoto then
            for i, photo in ipairs( photos ) do
                if photo == selPhotos.mostSelPhoto then
                    photoToBe = photo
                    break
                end
            end
        end
        if not photoToBe then
            photoToBe = photos[1]
        end
        catalog:setSelectedPhotos( photoToBe, photos ) -- make sure the photos to have their metadata saved are the ones selected.
    end

    
    local status = false
    local message = "unknown"
    
    if not alreadyInGridMode then
        app:sendKeys( 'g' ) -- confirmation requested below.
    end
    
    local m = {}
    m[#m + 1] = "Metadata must be read to ensure this operation is successful."
    m[#m + 1] = "After you click 'Read Metadata', you should see an extra \"Operation\" pop up in the upper left corner of Lightroom's main window - be looking for it... (if no other operations are in progress, it will say 'Reading Metadata')"
    m[#m + 1] = "If you are in grid mode, and there are no other dialog boxes open, then click 'Read Metadata' to begin. If there are other Lightroom/plugin dialog boxes open, then click 'Let Me Close Dialogs' and then do so (close them).  If you are not in grid mode, or you cant get dialogs to stay closed, then you must click 'Cancel', and retry again after remedying..."
    m[#m + 1] = "Click 'Read Metadata' when ready."
    m = table.concat( m, '\n\n' )
    
    local answer
    repeat
        answer = dialog:showInfo( m, "ReadMetadataPrompt", {{label='Read Metadata',verb='ok'},{label="Let Me Close Dialogs",verb='other'}} )
        if answer == 'other' then
            LrTasks.sleep( 3 )
        else
            break
        end
    until false
    repeat
        if answer == 'ok' then
            if WIN_ENV then
                if service and service.scope then
                    service.scope:setCaption( str:fmt( "Waiting for 'Read Metadata' confirmation..." ) ) -- only visible after the save metadata operation is complete.
                end
                status, message = app:sendWinAhkKeys( "{Alt Down}mr{Alt Up}" ) -- makes photo look changed again.
                if not status then
                    break
                end
            else
                error( "Program failure...") -- this will never happen.
            end
            local m = "Wait for the 'Read Metadata' operation to complete, then click 'Read Metadata is Complete'.\n \nYou can tell when its complete by looking in the upper left-hand corner of the main Lightroom window: it will say \"Waiting for 'Read Metadata' confirmation...\" when the operation is complete."
            local answer = dialog:showInfo( m, nil, 'Read Metadata is Complete', 'Read Metadata Never Started' )
            if answer == 'ok' then -- yes
                status = true
            elseif answer == 'cancel' then -- no
                status, message = false, "Apparently, metadata was not read - most often caused by dialog box interference. Try to eliminate dialog boxes, then attempt again..."
            elseif answer == 'other' then -- dunno
                status, message = nil, "Metadata must be read. Hint: to tell if it gets read, watch the progress indicator in the upper left-hand corner of the main Lightroom window."
            end
        elseif answer == 'cancel' then
            status, message = nil, "User canceled."
        else
            error( "invalid answer: " .. answer )
        end
    until true
    
    if restoreSelect then -- not restored upon program failure.
        cat:restoreSelPhotos( selPhotos )
    end
    return status, message    

end



--- Save selected photos for restoral later.
--
--  @usage     call if photo selection will be changed temporarily by plugin.
--             <br>- restore in cleanup handler.
--
--  @return    black box to pass to restoral function.
--
function Catalog:saveSelPhotos()
    return { mostSelPhoto = catalog:getTargetPhoto(), selPhotos = catalog:getTargetPhotos() }
end



--- Restore previously saved photo selection.
--
--  @usage     call in cleanup handler if photo selection was changed temporarily by plugin.
--
function Catalog:restoreSelPhotos( selPhotos )
    if selPhotos and selPhotos.mostSelPhoto and selPhotos.selPhotos then
        catalog:setSelectedPhotos( selPhotos.mostSelPhoto, selPhotos.selPhotos )
    end
end



return Catalog

