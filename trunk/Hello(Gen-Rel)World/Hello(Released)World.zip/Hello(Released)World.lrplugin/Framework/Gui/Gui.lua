--[[
        Gui.lua
--]]

local Gui, dbg = Object:newClass{ className = 'Gui' }



--- Constructor for extending class.
--
function Gui:newClass( t )
    return Object.newClass( self, t )
end



--- Constructor for new instance.
--
function Gui:new( t )
    local o = Object.new( self, t )
    return o
end



--- Assure library module / grid view, if not already.
--
--  @param promptKey -- key to remember confirmation answer, or 'persistent' to always prompt.
--
--  @usage This is the only way to make sure keystroke commands like Ctrl/Cmd-S target multiple photos.
--
--  @return true iff presumably grid mode confirmed. Note: this does not mean it really is so other forms of cross verification are welcome.
--
--[[function Gui:assureGridView( promptKey )

    local s, m = app:sendKeys( 'g' )
    if s then
        app:logInfo( "Lightroom should have gone to library module grid view.", App.verbose )
    else
        return false, "Unable to switch to grid view, error message: " .. str:to( m )
    end
    local msg = {}
    msg[#msg + 1] = "Lightroom should be in Library/Grid mode now, and must remain that way until this operation is complete."
    msg[#msg + 1] = "Click 'OK' to confirm grid view, or click 'Cancel' to abort."
    if promptKey == 'persistent' then
        promptKey = nil
    end
    local answer = dialog:showInfo( table.concat( msg, "\n\n" ), promptKey )
    if answer then
        return true
    else
        return false, "User did not confirm grid view."
    end
end--]]



--- Switch to specified module.
--
--  @param moduleNumber -- 1=library, 2=develop, ...
--
--  @usage No guarantees - involve user with a prompt if absolute assurance required.
--
function Gui:switchModule( moduleNumber )
    if moduleNumber == nil then
        error( 'Module number must not be nil' )
    end
    moduleNumber = tonumber( moduleNumber ) -- make it a number, if not already a number.
    if moduleNumber >= 1 and moduleNumber <= 5 then
        if WIN_ENV then
            return app:sendWinAhkKeys( "{Ctrl Down}{Alt Down}" .. moduleNumber .. "{Ctrl Up}{Alt Up}" )
        else
            return app:sendMacEncKeys( "CmdOption-" .. moduleNumber )
        end
    else
        return false, "Invalid module number: " .. str:to( moduleNumber )
    end
end
    


--- Assure library module / grid view, if not already.
--
--  @param promptKey -- key to remember confirmation answer, or 'persistent' to always prompt.
--
--  @usage This is the only way to make sure keystroke commands like Ctrl/Cmd-S target multiple photos.
--
--  @return true iff presumably grid mode confirmed. Note: this does not mean it really is so other forms of cross verification are welcome.
--
--[[function Gui:assureModule( moduleName, promptKey )

    local s, m = app:sendKeys( 'g' )
    if s then
        app:logInfo( "Lightroom should have gone to library module grid view.", App.verbose )
    else
        return false, "Unable to switch to grid view, error message: " .. str:to( m )
    end
    local msg = {}
    msg[#msg + 1] = "Lightroom should be in Library/Grid mode now, and must remain that way until this operation is complete."
    msg[#msg + 1] = "Click 'OK' to confirm grid view, or click 'Cancel' to abort."
    if promptKey == 'persistent' then
        promptKey = nil
    end
    local answer = dialog:showInfo( table.concat( msg, "\n\n" ), promptKey )
    if answer then
        return true
    else
        return false, "User did not confirm grid view."
    end
end--]]



return Gui
