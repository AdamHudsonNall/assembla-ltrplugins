--[[
        Filename:           Dialog.lua
        
        Synopsis:           Utilities to support building dialog boxes and such.

        Notes:              -
--]]

local Dialog, dbg = Object:newClass{ className = 'Dialog' }

-- static constants
Dialog.inputMsg = "$$$/X=^1 is requesting input..."
Dialog.isOkMsg = "$$$/X=^1 is asking if its OK..."
Dialog.confirmMsg = "$$$/X=^1 is asking..."
Dialog.infoMsg = "$$$/X=^1 has something to say..."
Dialog.warningMsg = "$$$/X=^1 is concerned..."
Dialog.errorMsg = "$$$/X=^1 has encountered a problem..."
Dialog.infoType = "info"
Dialog.warningType = "warning"
Dialog.errorType = "critical" -- @2008-02-13: appears same as warning (SDK version 2.0 or 2.2?) - try again after the next version of SDK is released. Maybe only different on Mac.



---  Constructor for extending class.
--
function Dialog:newClass( t )
    return Object.newClass( self, t )
end



--- Constructor for new instance.
--
function Dialog:new( t )
    local o = Object.new( self, t )
    o.answers = {}
    return o
end



--- Klugerian function whose impetus was to support log file contents copy-n-paste to email.
--
--  <p>Presents text in a multi-line edit-field with instructions to user to copy to clipboard...</p>
--
function Dialog:putTextOnClipboard( param )

    local button = 'undefined'
    
    local text = param.contents or 'Oops!'
    
    app:call( Call:new{ name = "text to clipboard", main = function( call )
        local props = LrBinding.makePropertyTable( call.context )
        props.copied = false
        local view = {} -- no bind-to object
        view[#view + 1] = vf:edit_field {
            value = text,
            width_in_chars = param.width_in_chars or 80,
            height_in_lines = param.height_in_lines or 27,
        }
        local s = {}
        s[#s+1] = "Instructions:"
        s[#s+1] = "1. If Log contents are not already selected (indicated by being all blue), then click anywhere in the text field, then press ^1 to select all text."
        s[#s+1] = "2. Press ^2 to copy to clipboard."
        s[#s+1] = "3. Check the confirmation box below."
        s[#s+1] = "4. Click 'OK'."
        s = table.concat( s, '\n' )
        view[#view + 1] = vf:static_text {
            title = param.subtitle or str:format( s, str:getCtrlKeySeq( "A" ), str:getCtrlKeySeq( "C" ) ),
        }
        param.accessoryView = vf:checkbox {
            title = 'I have successfully copied the contents to the clipboard, as instructed.',
            bind_to_object = props,
            value = bind( 'copied' ),            
        }
        param.title = param.title or "Copy to Clipboard"
        param.contents = vf:column( view )
        repeat
            button = LrDialogs.presentModalDialog( param )
            -- button = dialog:presentModalFrame( param, true )
            if props.copied then
                break -- good to go
            elseif button == 'ok' then
                self:showInfo( "Please revisit the instructions, or click cancel to abort..." )
            else
                break
            end
        until false
    end } )
    
    return button == 'ok'
    -- return button == 'copied'

end



--      Synopsis:           Returns the specified button if found in the dialog box.
--      
--      Notes:              specified by label, e.g. "OK"
--      
--      Returns:            button object or nil
--
function Dialog:_findButton (x, label, visited)
    if visited == nil then visited = {} end

    if type (x) ~= "table" or visited [x] then return nil end
    visited [x] = true
   
    if x._WinClassName == "AgViewWinPushButton" and x.title == label then
        return x
    else
        -- LrDialogs.message( x._WinClassName )
    end
           
    for k, v in pairs (x) do
        local result = self:_findButton (v, label, visited)
        if result then return result end
    end
   
    return nil
 end
 
 


--- Presents a modal dialog without an OK button.
--
--  @param          args                same as to lr-dialog -> present-modal-dialog
--  @param          returnAllButtons    true => return first button click, else hold out for 'cancel' button.
--
--  @usage          Only suitable if when you don't need form elements to be commited upon dismissal.
--      
--  @return         string: dismissal button (always 'cancel' if return-all-buttons is not asserted.
--
function Dialog:presentModalFrame( args, returnAllButtons )
    assert( args.actionVerb == nil, "Bad frame - shouldn't define action button." )
    assert( args.actionBinding == nil, "Bad binding - shouldn't define action binding." )
    assert( args.otherVerb == nil, "Bad frame - shouldn't define other button." )
	LrTasks.startAsyncTask( function()
	    while true do
	        local okButton = self:_findButton( args.contents, "OK" ) -- action-verb pre-checked, so the fram dismissal button will be labeled "OK".
	        if okButton then
	            okButton.enabled = false
	            okButton.visible = false
	            return
	        end
	        LrTasks.sleep( .1 )
	    end
	end )
	local button
	local done = false
    repeat
    	button = LrDialogs.presentModalDialog( args )
    	if not returnAllButtons then
        	if button ~= 'cancel' then -- will not commit last edited text field in this case ###3.
        	    -- _debugTrace( "Frame response should only be cancel." )
        	else
        	    done = true
        	end
        else
            done = true
        end
    until done
    return button
end



--- Prompt user to enter a string via simple dialog box.
--      
--  @param          param           table with the following elements:<ul>
--                                      <li>title - window frame title
--                                      <li>subtitle - static text banner at top of content.</ul>
--
--  @usage          self-wrapped.
--      
--  @return         string, or nil for cancelled.
--
function Dialog:getSimpleTextInput( param )

    local text, msg

    app:call( Call:new{ name="get simple text input", main=function( call )
    
        local props = LrBinding.makePropertyTable( call.context )
        local vf = LrView.osFactory()
    
        local args = {}
        args.title = param.title
        local viewItems = { bind_to_object = props }
        viewItems[#viewItems + 1] =
            vf:row {
                vf:static_text {
                    title = param.subtitle,
                },
            }
        viewItems[#viewItems + 1] =
            vf:row {
                vf:edit_field {
                    value = bind( 'text' ),
                    fill_horizontal = 1,
                },
            }
        args.contents = vf:view( viewItems )
        local button = LrDialogs.presentModalDialog( args )
        if button == 'ok' then
            text = props.text
        else
            msg = "Canceled"
        end
            
    end } )
    
    return text, msg
    
end



--- Fetch a user selection from a combo-box.
--      
--  @param              param               Table with the following elements:<ul>
--                                              <li>title - goes on window frame
--                                              <li>subtitle - static text banner goes in content at top.
--                                              <li>items - for combo box.</ul> 
--  @usage              self-wrapped.
--      
--  @return             string, or nil for cancel.
--
function Dialog:getComboBoxSelection( param )

    local text, msg
    
    app:call( Call:new{ name="get combo-box selection", async = false, main = function( call )
    
        repeat
        
            if tab:isEmpty( param.items ) then
                msg = "No items"
                break
            end
    
            local vf = LrView.osFactory()
            local props = LrBinding.makePropertyTable( call.context )
            
            props.text = param.items[1] -- can be optimized if inadequate.
        
            local args = {}
            args.title = param.title or 'Choose Item'
            local viewItems = { bind_to_object = props }
            viewItems[#viewItems + 1] =
                vf:row {
                    vf:static_text {
                        title = param.subtitle or "Choose an item from the drop-down list",
                    },
                }
            viewItems[#viewItems + 1] =
                vf:row {
                    vf:combo_box {
                        value = bind( 'text' ),
                        items = param.items,
                    },
                }
            args.contents = vf:view( viewItems )
            local button = LrDialogs.presentModalDialog( args )
            if button == 'ok' then
                text = props.text
            else
                msg = "Canceled"
            end
            
        until true
            
    end } )
    
    return text, msg
    
end




--- Allows user to select a folder by way of the "open file" dialog box.
--      
--  @param              param       table - same as run-open-panel, except all are optional:<ul>
--                          <li>title
--                          <li>prompt ("OK" button label alternative)
--                          <li>can-create-directories
--                          <li>file-types
--                          <li>initial-directory</ul>
--  @param              props       Properties into which folder path will be written.
--  @param              name        Name of property to write.
--      
--  @usage              Folder is written to named property if provided, in which case return value is typically ignored.
--
--  @return             string: path of folder, else nil if user cancelled.
--
function Dialog:selectFolder( param, props, name )

    local args = {}
    args.title = param.title or "Choose File"
    args.prompt = param.prompt or "OK"
    args.canChooseFiles = false
    if param.canCreateDirectories == nil then
        args.canCreateDirectories = false
    else
        args.canCreateDirectories = param.canCreateDirectories
    end
    args.canChooseDirectories = true
    args.allowsMultipleSelection = false
    args.initialDirectory = param.initialDirectory or "/" -- I hate defaulting to documents folder - put 'em at da top...

    local folders = LrDialogs.runOpenPanel( args )
    
    if folders then
        if props then
            props[name] = folders[1]
        end
        return folders[1]
    else
        return nil
    end
    
end



--- Allows user to select a file by way of the "open file" dialog box.
--      
--  @param              param       Same as run-open-panel, except all are optional:<ul>
--                          <li>title
--                          <li>prompt ("OK" button label alternative)
--                          <li>filetypes
--                          <li>initial-directory</ul>
--  @param              props       Properties into which folder path will be written.
--  @param              name        Name of property to write.
--      
--  @usage              File path is written to named property if provided, in which case return value is typically ignored.
--
--  @return             string: path of file, else nil if user cancelled.
--
function Dialog:selectFile( param, props, name )

    local args = {}
    args.title = param.title or "Choose File"
    args.prompt = param.prompt or "OK"
    args.canChooseFiles = true
    args.canCreateDirectories = false
    args.canChooseDirectories = false
    args.allowsMultipleSelection = false
    args.fileTypes = param.fileTypes or "*"
    args.initialDirectory = param.initialDirectory or "/" -- I hate defaulting to documents folder - put 'em at da top...

    local files = LrDialogs.runOpenPanel( args )
    
    if files then
        if props then
            props[name] = files[1]
        end
        return files[1]
    else
        return nil
    end
    
end



--- Present quick-tips dialog box.
--      
--  @param              table of "paragraph" strings - will be concatenated with double EOL between.
--
--  @usage              Convenience function for presenting a help string with standard title, buttons, and link to web for more info.
--      
function Dialog:quickTips( strTbl )
    local helpStr
    if type( strTbl ) == 'table' then
        helpStr = table.concat( strTbl, "\n\n" )
    elseif type( strTbl ) == 'string' then
        helpStr = strTbl
    else
        helpStr = "Sorry - no quick tips."
    end
    local button = self:showInfo( helpStr, nil, "More on the Web", "That's Enough" )
    if button == 'ok' then
        LrHttp.openUrlInBrowser( app:getPluginUrl() ) -- get-plugin-url returns a proper url for plugin else site home.
    end

end



--- Show what may be important information to the user - to make it optional, pass an action pref key.
--
--  @param    msg               Message to be shown.
--  @param    actionPrefKey     Key for do-not-show.
--  @param    okButtonOrButtonTable     ok-button (string), OR table of button specs for prompt-for-action-with-do-not-show,<br>
--                                      in which case action-pref-key required. table element format:<ul>
--                                          <li>label - button display text
--                                          <li>verb - return string
--                                          <li>(note: cancel comes free, so just need action and optionally other).
--                                          <li>(cancel & other button parameters ignored).</ul>
--              - nil for message with do not show & default buttons.
--              
--  @param      cancelButton    string: ignored if buttons passed as table.
--  @param      otherButton     string: (optional) requires ok and cancel buttons preceding.
--
--  @return     dismissal button as string.
--
function Dialog:showInfo( msg, actionPrefKey, okButtonOrButtonTable, cancelButton, otherButton )

    local message = LOC( Dialog.infoMsg, app:getAppName() )
    local info = msg

	if actionPrefKey then
        if okButtonOrButtonTable then
            assert( type( okButtonOrButtonTable ) == 'table', "Buttons should be table." )
            local args = {}
            args.message = message
            args.info = info
            args.actionPrefKey = actionPrefKey
            args.verbBtns = okButtonOrButtonTable
		    return LrDialogs.promptForActionWithDoNotShow( args )
        else
		    LrDialogs.messageWithDoNotShow( { message=message, info=info, actionPrefKey=actionPrefKey } )
        end
	else
        if okButtonOrButtonTable then -- button string
            assert( type( okButtonOrButtonTable ) == 'string', "Buttons should be string." )
            return LrDialogs.confirm( message, info, okButtonOrButtonTable, cancelButton, otherButton )
        else
    	    LrDialogs.message( message, info, Dialog.infoType )
        end
	end

end



--- Show information, and remember answer for a while.
--
--  @usage          How long answer is remembered is governed by the plugin - generally memory lasts for the duration of a service.
--  @usage          Must be used in conjunction with "forget-answer" or there's not much point in it...
--  @usage          Unlike normal Lr memory, remembers "cancel" answer as well.
--
function Dialog:showInfoAndRememberAnswer( msg, memKey, memText, okButton, cancelButton, otherButton )

    local answer

    LrFunctionContext.callWithContext( memKey, function( context )
    
        local props = LrBinding.makePropertyTable( context )
        props.box = false

        local message = LOC( Dialog.confirmMsg, app:getAppName() )
        local info = msg
    
    	if not str:is( memKey ) then
    	    error( "need key to remember answer" )
    	end
    	
        answer = self.answers[memKey]
        if answer then
            return
        end
        
        local viewItems = {} -- no properties on main view.
        viewItems[#viewItems + 1] = vf:static_text{
            title = msg,
        }
        
        local args = {}
        --args.title = "Please answer by clicking button"
        args.title = message
        args.contents = vf:view( viewItems )
        args.accessoryView = vf:row { 
            vf:push_button{
                title = otherButton,
                action = function( button )
                    LrDialogs.stopModalWithResult( button, 'other' )
                end,
            },
            vf:spacer{
                alignment = 'right',
                fill_horizontal = 1,
            },
            vf:checkbox{
                title = memText or "Do same for remainder...",
                bind_to_object = props,
                value = bind( 'box' ),
            },
        }
        args.resizable = true
        args.save_frame = memKey
        args.actionVerb = okButton
        args.cancelVerb = cancelButton
        args.otherVerb = otherButton
    
        answer = LrDialogs.presentModalDialog( args )
        if props.box then
            self.answers[memKey] = answer
        end
        
    end )
    
    return answer
    
end



--- Forget previously remembered answer.
--
--  @usage Call before a loop where you always want user to answer the first time, even if not subsequently.
--
function Dialog:forgetAnswer( memKey )
    self.answers[memKey] = nil
end



--- Get answer if rememebered.
--
function Dialog:getAnswer( memKey )
    local answer = self.answers[memKey]
    return answer
end



--- Remember answer.
--
--  @usage      Used in case presentation is via custom dialog box.
--
function Dialog:rememberAnswer( memKey, answer )
    self.answers[memKey] = '' .. answer -- remember a copy, since Lr likes to garbage collect properties.
end



--- Show warnings to user, display of which is not optional - use info if its an optional warning.
--		
--	@usage              This does not increment warning count. - Generally used in conjunction with log-warning.
--
--  @see                Dialog:showInfo
--
function Dialog:showWarning( msg, b1, b2, b3 )
    local message = LOC( Dialog.warningMsg, app:getAppName() )
    local warning = msg
    local retVal = nil
    if b1 or b2 or b3 then
        retVal = LrDialogs.confirm( message, warning, b1, b2, b3 )
    else
  	    LrDialogs.message( message, warning, Dialog.warningType )
  	end
    return retVal
end



--- Showing of errors is never optional.
--
--	@usage              This does not increment ERROR count. - Generally used in conjunction with log-error.
--
--  @see                Dialog:showInfo
--
function Dialog:showError( msg, b1, b2, b3 )
    local message = LOC( Dialog.errorMsg, app:getAppName() )
    local _error = msg
    local retVal = nil
    if b1 or b2 or b3 then
        retVal = LrDialogs.confirm( message, _error, b1, b2, b3 )
    else
  	    LrDialogs.message( message, _error, Dialog.errorType )
  	end
    return retVal
end



--- Determine if its OK with the user to do something, or not - aLways prompts.
--
--	<p>For more complex prompts, use confirm box directly.</p>
--
--  @param  msg     string message.
--
--  @return boolean true iff is ok.
--
function Dialog:isOk( msg )
    local answer = LrDialogs.confirm( LOC( Dialog.isOkMsg, app:getAppName() ), msg )
    return answer == 'ok'
end



--- Prompt user to continue or not, with option to remember decision.
--
--  @param  msg     string message.
--  @param  id      string key for dismissal option.
--
--  @usage  Same as is-ok plain, except with option to suppress next time.
--
--  @return boolean true iff is user answered ok this time or previously...
--
function Dialog:isOkOrDontAsk( msg, id )
    local t = {}
    t[1] = { label="OK", verb="ok" }
    local args = {}
    args.message = LOC( Dialog.isOkMsg, app:getAppName() )
    args.info = msg
    args.actionPrefKey = id
    args.verbBtns = t
    local answer = LrDialogs.promptForActionWithDoNotShow( args )
    return answer == 'ok'
end    



return Dialog
