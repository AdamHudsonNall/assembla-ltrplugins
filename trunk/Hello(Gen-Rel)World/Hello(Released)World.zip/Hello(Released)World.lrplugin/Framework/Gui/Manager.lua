--[[
        Manager.lua
        
        Plugin manager UI support.
--]]

local Manager, dbg = Object:newClass{ className = 'Manager' }



--- Constructor for extending class.
--
function Manager:newClass( t )
    return Object.newClass( self, t )
end



--- Constructor for new instance.
--
function Manager:new( t )
    return Object.new( self, t )
end



--- Preference change handler.
--
--  <p>Handles change to preferences that are associated with a property table in the plugin manager UI.<br>
--  Examples: adv-dbg-ena, pref-set-name.</p>
--
--  @param      props       Properties associated with value change.
--  @param      prefs       Preferences associated with value change.
--  @param      name        Preference name.
--  @param      value       New preference value.
--
--  @usage      *** IMPORTANT: The base class method is critical and must be called by derived class.
--  @usage      Changed items are typically changed via the UI and are bound directly to lr-prefs.
--              <br>props are not bound to prefs explicitly/directly, but need to be reloaded if the pref set name changes.
--
function Manager:prefChangeHandlerMethod( props, _prefs, name, value )
    -- dbg( "Pref Changed: ", str:format( "^1: ^2", name, str:to( value ) ) )
    if name == app:getGlobalPrefKey( 'advDbgEna' ) then
        if value then
            if app:getGlobalPref( 'classDebugEnable' )  then
                app:setGlobalPref( "classDebugSynopsis", "Active" )
            else
                app:setGlobalPref( "classDebugSynopsis", "Inactive" )
            end    
            Debug.init( true )
        elseif value ~= nil then
            Debug.init( false )
            app:setGlobalPref( "classDebugSynopsis", "" )
        end
        
        
    elseif name == app:getGlobalPrefKey( 'classDebugEnable' ) then
        if value then
            if app:getGlobalPref( 'advDbgEna' ) then
                app:setGlobalPref( "classDebugSynopsis", "Active" )
            else
                app:setGlobalPref( "classDebugSynopsis", "" )
            end            
        else
            if app:getGlobalPref( 'advDbgEna' ) then
                app:setGlobalPref( "classDebugSynopsis", "Inactive" )
            else
                app:setGlobalPref( "classDebugSynopsis", "" )
            end            
        end    
                
    elseif name == app:getGlobalPrefKey( 'presetName' ) then
        app:presetNameChange( props, name, value )
    elseif name == app:getGlobalPrefKey( 'logVerbose' ) then
        app.logr:enable{ verbose = value }
    else
        dbg( "Need to handle change to ", name )
    end
end



--- Plugin manager property change handler.
--
--  @usage          Handles changes to property table for UI elements that are NOT specifically/directly bound to a lr-preference.
--  @usage          By default, this method simply sets the corresponding preference which may be from a named set, or the unnamed (default) set.
--  @usage          *** IMPORTANT: Derived class may need to call base class method, or at a minimum, make sure changed prefs are set.
--
function Manager:propChangeHandlerMethod( props, name, value )
    -- dbg( "Prop Change Set: ", str:format( "^1 ^2: ^3", app:getGlobalPref( 'presetName' ), name, str:to( value ) ) )
    if name == 'testData' then
        -- dbg( 'base manager seeing test-data property change' )
    end
    app:setPref( name, value )
end



--- Start dialog method.
--
--  @usage      *** IMPORTANT: The base class method is critical and must be called by derived class,
--              <br>AFTER initializing all the pref values, so they get loaded into props.
--
function Manager:startDialogMethod( props )

    dbg("loading props corresponding to set ", app:getGlobalPref( 'presetName' ) )
    app:switchPreset( props )
    
    prefs:addObserver( app:getGlobalPrefKey( 'advDbgEna' ), props, Manager.prefChangeHandler )
    prefs:addObserver( app:getGlobalPrefKey( 'classDebugEnable' ), props, Manager.prefChangeHandler )
    prefs:addObserver( app:getGlobalPrefKey( 'presetName' ), props, Manager.prefChangeHandler )
    prefs:addObserver( app:getGlobalPrefKey( 'logVerbose' ), props, Manager.prefChangeHandler )
    
    for k,v in props:pairs() do
        props:addObserver( k, Manager.propChangeHandler )
    end
end



--- Sections for top of dialog method.
--
--  @usage      Derived class is free to call to include standard sections, or override completely...
--
function Manager:sectionsForTopOfDialogMethod( vf, props )

    local infoSection = { bind_to_object = prefs }
    
    local compatStr = app:getCompatibilityString()
    
    infoSection.title = app:getPluginName()
    infoSection.synopsis = compatStr
	infoSection.spacing = vf:label_spacing()

    infoSection[#infoSection + 1] = 
		vf:row {
			vf:static_text {
				title = compatStr,
			},
			vf:static_text {
				title = 'Author: ' .. app:getAuthor(),
			},
			vf:static_text {
				title = "Author's Website: " .. app:getAuthorsWebsite(),
			},
		}
		
	infoSection[#infoSection + 1] = vf:spacer{ height=5 }
	
-- BEGIN CONDITIONAL buyPlugin

    local buyUrl = app:getInfo( "buyUrl" ) or false
    
    -- get rid of button if copy is licensed?
    
    if buyUrl then
    
    	infoSection[#infoSection + 1] = 
    		vf:row {
    			vf:push_button {
    				title = "Buy " .. app:getPluginName(),
    				font = "<system/bold>",
    				width = share( "button_width" ),
    				action = function( button )
    				    app:call( Call:new{ name = "Buy", main=function()
                            LrHttp.openUrlInBrowser( buyUrl )
                        end } )
    				end
    			},
    			vf:static_text {
    				title = str:format( "Go to website with purchasing info..." ),
    			},
    		}
    end

-- END CONDITIONAL buyPlugin

-- BEGIN CONDITIONAL donate

    local donateUrl = app:getInfo( "donateUrl" ) or false
    
    if donateUrl then
    	infoSection[#infoSection + 1] = 
    		vf:row {
    			vf:push_button {
    				title = "Donate",
    				font = "<system/bold>",
    				width = share( "button_width" ),
    				action = function( button )
    				    app:call( Call:new{ name = "Buy", main=function()
    	                    LrHttp.openUrlInBrowser( donateUrl )
                        end } )
    				end
    			},
    			vf:static_text {
    				title = str:format( "Go to website with donating info..." ),
    			},
    		}
    end

-- END CONDITIONAL donate

    if buyUrl or donateUrl then
    	infoSection[#infoSection + 1] = vf:spacer{ height=5 }
    	infoSection[#infoSection + 1] = vf:separator{ fill_horizontal = 1 }
    end
	infoSection[#infoSection + 1] = vf:spacer{ height=5 }
	
	infoSection[#infoSection + 1] = 
		vf:row {
			vf:push_button {
				title = "Reset Warning Dialogs",
				width = share( "button_width" ),
				action = function( button )
                    LrDialogs.resetDoNotShowFlag()
                    dialog:showInfo( "Warning dialogs have been reset." )
				end
			},
			vf:static_text {
				title = LOC( '$$$/X=Show all ^1 dialog boxes that previously were marked "Do Not Show"', app:getAppName() ),
			},
		}

    local cbRow = {}		
		
-- BEGIN CONDITIONAL updateOption

    if app:getInfo( "xmlRpcUrl" ) then
    	infoSection[#infoSection + 1] = 
    		vf:row {
    			vf:push_button {
    				title = "Check for Update",
    				width = share( "button_width" ),
    				action = function( button )
                        app:checkForUpdate()
    				end
    			},
    			vf:static_text {
    				title = str:format( "Check for newer version of ^1 via the internet.", app:getPluginName() ),
    			},
    		}
    end

-- END CONDITIONAL updateOption

	infoSection[#infoSection + 1] = 
		vf:row {
			vf:push_button {
				title = "View Logs",
				width = share( "button_width" ),
				action = function( button )
                    app:showLogFile()
				end
			},
			vf:static_text {
				title = str:format( "Show log file using default app." ),
			},
		}
	
	infoSection[#infoSection + 1] = 
		vf:row {
			vf:push_button {
				title = "Clear Logs",
				width = share( "button_width" ),
				action = function( button )
				    app:call( Call:new{ name=button.title, async=true, guard=App.guardSilent, main=function( call )
                        app:clearLogFile()
                    end } )
				end
			},
			vf:static_text {
				title = str:format( "Clear log file by moving it to trash." ),
			},
		}
	
	infoSection[#infoSection + 1] = 
		vf:row {
		    vf:push_button {
    			title = "Send Logs to " .. app:getAuthor(),
    			width = share( "button_width" ),
    			action = function( button )
    			    app:call( Call:new{ name = "Send log file", guard = App.guardVocal, main = function( context , ... )
    			        local contents, message = app:getLogFileContents()
    			        if contents then
    			            local ok = dialog:putTextOnClipboard{ title="Copy Log Contents To Clipboard", contents=contents }
    			            if ok then
    			                LrHttp.openUrlInBrowser( "mailto:rob@robcole.com?subject=" .. app:getPluginName() .. " Log File" .. "&body=Replace this text with the contents of the log file, which should still be on the clipboard, which you can paste by clicking anywhere in the body of the email, then pressing " .. str:getCtrlKeySeq( 'V' ) .. ". Then, make sure you include a detailed explanation of the problem you've encountered, and if possible - the steps that will be required for me to reproduce the problem. There should be a dialog box open in Lightroom with more instructions..." ) -- Drive-by (does not wait).
                                dialog:showInfo( "Your browser should have opened your mailer with a new email message to send.\n\nIf you haven't already done so, please paste the log contents from the clipboard into the body of the email (first click anywhere in the body of the email, then press " .. str:getCtrlKeySeq( 'V' ) .."), then send." )
    			            else
    			                --
    			            end
    			        else
    			            app:showError( "Unable to get log contents, error message: " .. message )
    			        end
    			     
    			    end, finale = function( call, status, message )
    			        if status then
                        else
                            dialog:showError( "Unable to send logs, error message: " .. message )
                        end
                    end } )
    			end
   			},
			vf:static_text {
				title = str:format( "Send logs via your default email client.", app:getPluginName() ),
			},
		}

-- BEGIN CONDITIONAL updateOption

    if app:getInfo( "xmlRpcUrl" ) then
        if gbl:getValue( "xmlRpc" ) then
            if xmlRpc.url then
            	cbRow[#cbRow + 1] = 
            		vf:checkbox {
            			title = "Check for updates upon startup.",
            			value = app:getGlobalPrefBinding( 'autoUpdateCheck' ),
            		}
            else
                error( "xml-rpc url must be specified in init.lua" )
            end
        else
            error( "xml-rpc object must be instantiated to support update-option - hint: define url in config file." )
        end
    end
		
-- END CONDITIONAL updateOption


		
	infoSection[#infoSection + 1] = vf:spacer{ height=5 }
		
	
    cbRow[#cbRow + 1] = 
		vf:checkbox {
			title = "Verbose Logging",
			value = app:getGlobalPrefBinding( 'logVerbose' ),
		}
		
	infoSection[#infoSection + 1] = vf:row( cbRow )
	
		
		
	--   C L A S S    D E B U G 

    local advDbgSection
	
	if not app:isRelease() then
	
        advDbgSection = { bind_to_object = prefs }
        
    	advDbgSection.title = "Debug"
    	advDbgSection.synopsis = bind {
    	    keys = { app:getGlobalPrefKey( 'advDbgEna' ), app:getGlobalPrefKey( 'classDebugEnable' ) },
    	    bind_to_object=prefs,
    	    transform = function()
	            if app:getGlobalPref( 'advDbgEna' ) then
	                if app:getGlobalPref( 'classDebugEnable' ) then
	                    return "Restricted"
	                else
	                    return "Enabled"
	                end
	            else
	                return "Disabled"
	            end
    	    end
    	}
    	    
    	advDbgSection.spacing = vf:label_spacing()

    	
    	advDbgSection[#advDbgSection + 1] = 
    		vf:row {
        		vf:checkbox {
        			title = "Enable Interactive Debugger",
        			value = app:getGlobalPrefBinding( 'advDbgEna' ),
        		},
        		vf:push_button {
        			title = "Clear Log",
        			action = function( button )
        			    app:clearDebugLog() -- wrapped internally
                    end,
        		},
        		vf:push_button {
        			title = "Show Log",
        			action = function( button )
        			    app:showDebugLog() -- wrapped internally.
                    end,
        		},
        		vf:push_button {
        			title = "Debug Script",
        			action = function( button )
        			    app:call( Call:new { name='Debug Script', async=false, main=function( call )
                            if gbl:getValue( "DebugScript" ) then
                                DebugScript.showWindow()
                            else
                                dialog:showError( "DebugScript.lua has not been loaded." )
                            end
                        end } )
                    end,
        		},
    		}

    	advDbgSection[#advDbgSection + 1] = vf:spacer { height = 5 }
    	advDbgSection[#advDbgSection + 1] = 
		    vf:checkbox {
			    value = app:getGlobalPrefBinding( 'classDebugEnable' ),
			    enabled = app:getGlobalPrefBinding( 'advDbgEna' ),
				title = "Restrict debugging to selected classes only:",
			}
    	advDbgSection[#advDbgSection + 1] = vf:separator { fill_horizontal = 1 }

    		
    	local items = Object.getClassItems()
    	local columns = 3
        local rowItems = {}
    	for i = 1, #items do
    	
            repeat
    	
                local fullClassName = items[i]
                
                -- dbg( "Item: ", fullClassName )
    
                local propKey = Object.classRegistry[fullClassName].propKey
                
                app:initGlobalPref( propKey, false )
                
        	    rowItems[#rowItems + 1] = vf:checkbox {
        		    title = fullClassName,
        		    value = app:getGlobalPrefBinding( propKey ),
        		    enabled = LrBinding.andAllKeys( app:getGlobalPrefKey( 'classDebugEnable' ), app:getGlobalPrefKey( 'advDbgEna' ) ),
        		    width = share( "col_width" ),
        		}
        		if #rowItems == columns then
                    advDbgSection[#advDbgSection + 1] = vf:row( rowItems )
                    rowItems = {}
                end
        		
        	until true
        	
        end
        if #rowItems > 0 then
            advDbgSection[#advDbgSection + 1] = vf:row( rowItems )
        end
    end


    if advDbgSection and #advDbgSection then		
        return { infoSection, advDbgSection }
    else
        return { infoSection }
    end
end



--- Sections for bottom of dialog method.
--
--  @usage      *** Required for named preference set support - must be called in derived class if named preferences are to be supported and this method is overridden.
--
function Manager:sectionsForBottomOfDialogMethod( vf, props )

    if Preferences == nil then
        return {}
    end
    
    local appSection = { bind_to_object = props }
    
	-- appSection.title = app:getAppName() .. " Presets"
	appSection.title = "Preset Manager"
	appSection.synopsis = bind{ key=app:getGlobalPrefKey( 'presetName' ), object=prefs }

	appSection.spacing = vf:label_spacing()

    if app:isAdvDbgEna() then
    	appSection[#appSection + 1] = 
    		vf:row {
    			vf:push_button {
    				title = "Clear All Settings",
    				props = props,
    				action = function( button )
    				    app:call( Call:new{ name=button.title, async = false, main = function()
    				        local answer = dialog:showInfo( "*** Click 'Clear All' to thoroughly wipe all settings associated with this plugin, or click 'Reset Globals' to just reset global preferences to factory default values.\n \nNote: No preference support files will be deleted, and only in the case of 'Reset Globals' - no preset settings will be affected.", nil, 'Clear All', 'Cancel', 'Reset Globals' )
    				        if answer == 'ok' then
                                app:clearAllPrefs( button.props ) -- and load properties with default set.
                                dialog:showInfo( "All settings have been cleared - *** IMPORTANT: you must reload plugin now to avoid problems (consider re-enabling advanced debug first)." )
    				        elseif answer == 'other' then
                                app.prefMgr:loadGlobalDefaults()
                                dialog:showInfo( "Global preference settings have been reset to factory defaults - named and un-named preset settings were unaffected, however you may have to re-select."  )
                            elseif answer == 'cancel' then
                                -- dbg( "Canceled" )
                            else
                                error( "whats the answer?" )
                            end
                        end } )
    				end
    			},
    			vf:static_text {
    				title = str:format( 'Clear All ^1 settings (or just reset globals to factory defaults).', app:getAppName() ),
    			},
    		}
    end
		
	appSection[#appSection + 1] = vf:spacer{ height = 3 }
	
	appSection[#appSection + 1] =
	    vf:row {
    	    vf:edit_field {
    	        bind_to_object = prefs,
    	        value = app:getGlobalPrefBinding( 'presetName' ),
    	        width_in_chars = 20,
    	    },
    		vf:static_text {
    			title = str:format( 'Enter preset name - to be created if not already existing, else loaded.' ),
    		},
    	}
	appSection[#appSection + 1] =
	    vf:row {
    	    vf:push_button {
    	        title = 'Select Preset',
    	        width = share( 'pref_set_button_width' ),
    	        props = props,
    	        action = function( button )
    	            local items = app.prefMgr:getPresetItems() -- ###3 Gui-mngr and the pref-mgr are friends.
    	            if #items > 0 then
        	            local param = {}
        	            param.title = 'Choose Preset'
        	            param.subtitle = 'Choose a preset to load settings'
        	            param.items = items
        	            local sel,msg = dialog:getComboBoxSelection( param )
        	            -- dbg( "sel", sel )
        	            if sel then
        	                -- change handler will take care of the reset after setting value.
        	                if sel == '"Un-named"' then
            	                app:setGlobalPref( 'presetName', nil ) -- Setting to 'Default' here seems to work (change handler converts it to ''), sometimes but not always...
            	            else
            	                app:setGlobalPref( 'presetName', sel )
            	            end
            	        end
        	        else
        	            app:showWarning( "No named presets have been saved - try entering a name in the preset name box..." )
        	        end
    	        end
    	    },
    		vf:static_text {
    			title = str:format( 'Select name of preset and load settings.' ),
    		},
    	}
	appSection[#appSection + 1] =
	    vf:row {
    	    vf:push_button {
    	        title = 'Delete Preset',
    	        enabled = bind{ key=app:getGlobalPrefKey( 'presetName' ), bind_to_object=prefs, transform=function( value, fromModel )
    	            if str:is( value ) then
    	                return true
    	            else
    	                return false
    	            end
    	        end },
    	        width = share( 'pref_set_button_width' ),
    	        props = props,
    	        action = function( button )
                    app:call( Call:new{ name='Delete Pref Preset', main = function()
        	            app:deletePrefPreset( button.props )
                    end } )
    	        end
    	    },
    		vf:static_text {
    			title = str:format( 'Delete settings associated with the named preset.' ),
    		},
    	}
    	
	appSection[#appSection + 1] =
	    vf:row {
    	    vf:push_button {
    	        title = 'Load Defaults',
    	        width = share( 'pref_set_button_width' ),
    	        props = props,
    	        action = function( button )
                    app:call( Call:new{ name='Delete Pref Preset', main = function()
                        local presetName = app.prefMgr:getPresetName( true )
                        if dialog:isOk( str:fmt( "Overwrite ^1 settings with factory defaults?", presetName ) ) then
            	            app.prefMgr:loadDefaults( button.props ) -- nothing returned.
            	            dialog:showInfo( "Defaults were successfully loaded.", "DefaultPrefsLoadedPrompt" )
            	        end
                    end } )
    	        end
    	    },
    		vf:static_text {
    			title = str:format( 'Reset settings for this preset to factory default values.' ),
    		},
    	}
    	
    if app.prefMgr:isBackedByFile() then -- use app method?
    	appSection[#appSection + 1] =
    	    vf:row {
        	    vf:push_button {
        	        title = 'Advanced Settings',
        	        width = share( 'pref_set_button_width' ),
        	        props = props,
        	        action = function( button )
        	            app:call( Call:new{ name=button.title, main = function()
      	                    local file, name = app.prefMgr:getPrefSupportFile()
      	                    if fso:existsAsFile( file ) then
      	                        local answer = app:showInfo( str:format( "Open ^1 in ^2 default app?", name, app:getPlatformName() ), "OpenPrefBackerInDefaultApp", {{label="Edit",verb='ok'}} )
      	                        if answer == 'ok' then
          	                        app:openFileInDefaultApp( file )
          	                    else
          	                        -- dbg( "answer:", answer )
          	                    end
          	                else
          	                    app:showError( "Not existing: " .. file ) -- Its created when the set is created, and each time when switching sets - so simple error here OK.
          	                end
        	            end } )
        	        end
        	    },
        		vf:static_text {
        			title = str:format( 'Edit preset support file.' ),
        		},
        	}
        end
    
    return { appSection }
end



--- Called when dialog box is being exited for whatever reason.
--      
--  <p>Typically a good place to make sure settings have been saved.</p>
--
--  @usage      The base method just saves everything - override to descriminate.
--
function Manager:endDialogMethod( props )

    dbg( "End-of-dialog, saving properties..." )
    local count = 0

    for k,v in props:pairs() do
        if app:isVerbose() then
            dbg( "Saving: ", str:format( "^1 ^2: ^3", app:getGlobalPref( 'presetName' ), str:to( k ), str:to( v ) ) )
        end
        if str:isStartingWith( k, '_global_' ) then
            dbg( "Skipping global save: ", k )
        else
            count = count + 1
            app:setPref( k, v )
        end
    end

    dbg( "End-of-dialog, properties saved: ", str:to( count ) )
    
end



---------------------------------------------------------------------------------



--- Preference change handler.
--
--  Static function required by Lightroom.
--  Derived classes should override method instead.
--
function Manager.prefChangeHandler( props, _prefs, name, value )
    assert( Manager.manager ~= nil, "Manager nil" )
    app:call( Call:new{ name="mgrPrefChgHdlr", async = false, guard = App.guardSilent, main = function( call )
        Manager.manager:prefChangeHandlerMethod( props, _prefs, name, value )
    end } )
end    



--- Property change handler.
--
--  Static function required by Lightroom.
--  Derived classes should override method instead.
--
function Manager.propChangeHandler( props, name, value )
    assert( Manager.manager ~= nil, "Manager nil" )
    app:call( Call:new{ name="mgrPropChgHdlr", async = false, guard = App.guardVocal, main = function( call ) -- need silent guarding.
        Manager.manager:propChangeHandlerMethod( props, name, value )
    end } )
end
    


--- Called when dialog box is being initialized for plugin.
--
--  Static function simply creates an appropriate manager instance
--  and dispatches its start-dialog method.
--
--  Derived classes should override methods, not static functions.
--
function Manager.startDialog( props )
    if Manager.manager == nil then
        Manager.manager = objectFactory:newObject( Manager )
    end
    Manager.manager:startDialogMethod( props )
end



--- Called when dialog box is being exited for whatever reason.
--      
--  Static function required by Lightroom.
--  Derived classes should override method instead.
--
function Manager.endDialog( props )
    assert( Manager.manager ~= nil, "Manager nil" )
    Manager.manager:endDialogMethod( props )
end



--- Create top section of dialog.
--
--  Static function required by Lightroom.
--  Derived classes should override method instead.
--
function Manager.sectionsForTopOfDialog( vf, props )
    if Manager.manager == nil then -- this is never necessary when everything is in straight, but allows for a much more intelligible error message.
        Manager.manager = objectFactory:newObject( Manager )
    end
    assert( Manager.manager ~= nil, "Manager nil" )
    return Manager.manager:sectionsForTopOfDialogMethod( vf, props )
end



--- Create bottom section with settings.
--
--  Static function required by Lightroom.
--  Derived classes should override method instead.
--
function Manager.sectionsForBottomOfDialog( vf, props )
    if Manager.manager == nil then -- this is never necessary when everything is in straight, but allows for a much more intelligible error message.
        Manager.manager = objectFactory:newObject( Manager )
    end
    assert( Manager.manager ~= nil, "Manager nil" )
    return Manager.manager:sectionsForBottomOfDialogMethod( vf, props )
end



return Manager
