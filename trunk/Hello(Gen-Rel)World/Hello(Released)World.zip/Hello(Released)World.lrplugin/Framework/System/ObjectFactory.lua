--[[
        ObjectFactory.lua
        
        Creates objects used in the guts of the framework.
        Serves as a hook for apps to be able to control the classes of objects that get created,
        without having to override gobs of stuff to get to them.
        
        Generally, this is edited when new objects are created in the framework that are not 
        globally accessible. Plugin authors making plugins out of the new framework will generally
        edit the derived type: special-object-factory, if they've extended said classes.
--]]

local ObjectFactory, dbg = Object:newClass{ className = 'ObjectFactory', register = false }



--- Constructor for extending class.
--
function ObjectFactory:newClass( t )
    return Object.newClass( self, t )
end



--- Constructor for new instance.
--
function ObjectFactory:new( t )
    local o = Object.new( self, t )
    return o
end



function ObjectFactory:frameworkModule( spec )
    -- return load:frameworkModule( spec )
    return require( spec )
end



--- "Manufacture" a new instance object by class name.
--
--  @param      className        Partial class name if unique, otherwise full-class-name.
--  @param      ...              Passed to object constructor.
--
function ObjectFactory:newObject( class, ... )
    if type( class ) == 'table' then
        if class.new then
            return class:new( ... )
        end
    elseif type( class ) == 'string' then
        if class == 'Init' then
            return Init:new()
        elseif class == 'OperatingSystem' then
            if WIN_ENV then
                return Windows:new()
            else
                return Mac:new()
            end
        elseif class == 'ExportDialog' then
            return Export:newDialog( ... )
        elseif class == 'Export' then
            return Export:newExport( ... )
        end
    end
    error( "Unable to create object of this class: " .. tostring( class or 'nil' ) )
end



return ObjectFactory