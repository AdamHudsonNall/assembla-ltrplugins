--[[
        Init.lua (framework)
--]]



local Init, dbg = Object:newClass{ className = 'Init', register = false }


function Init:newClass( t )
    return Object.newClass( self, t )
end

function Init:new( t )
    return Object.new( self, t )
end



function Init:framework()

    local reloading = gbl:getValue( 'reloading' )

    gbl:initVar( 'shutdown', false, reloading ) -- the default shutdown function simply sets this flag. Plugin tasks can simply poll for it.
    gbl:initVar( 'enabled', true, reloading ) -- used by background task. Could be only conditionally included, but its so cheap...
    
    
    --   G L O B A L   L I G H T R O O M   M O D U L E S   -   B A S E L I N E
    gbl:initVar( 'LrPathUtils', import 'LrPathUtils', reloading )
    gbl:initVar( 'LrFileUtils', import 'LrFileUtils', reloading ) 
    gbl:initVar( 'LrErrors', import 'LrErrors', reloading ) 
    gbl:initVar( 'LrApplication', import 'LrApplication', reloading )
    gbl:initVar( 'LrTasks', import 'LrTasks', reloading )
    gbl:initVar( 'LrShell', import 'LrShell', reloading )
    gbl:initVar( 'LrStringUtils', import 'LrStringUtils', reloading )
    gbl:initVar( 'LrDate', import 'LrDate', reloading )
    gbl:initVar( 'LrProgressScope', import 'LrProgressScope', reloading )
    gbl:initVar( 'LrFunctionContext', import 'LrFunctionContext', reloading )
    gbl:initVar( 'LrPrefs', import 'LrPrefs', reloading )
    gbl:initVar( 'LrView', import 'LrView', reloading )
    gbl:initVar( 'LrBinding', import 'LrBinding', reloading )
    gbl:initVar( 'LrDialogs', import 'LrDialogs', reloading )
    gbl:initVar( 'LrLogger', import 'LrLogger', reloading )
    gbl:initVar( 'LrSystemInfo', import 'LrSystemInfo', reloading )
    gbl:initVar( 'LrHttp', import 'LrHttp', reloading )
    gbl:initVar( 'LrColor', import 'LrColor', reloading )
    gbl:initVar( 'LrXml', import 'LrXml', reloading )
    gbl:initVar( 'LrMD5', import 'LrMD5', reloading )
    
    
    
    --   G L O B A L   L I G H T R O O M   O B J E C T S   -   B A S E L I N E
    gbl:initVar( 'prefs', LrPrefs.prefsForPlugin(), reloading ) -- *** Use sparingly: go through App/Prefs API whenever possible.
    gbl:initVar( 'catalog', LrApplication.activeCatalog(), reloading )
    gbl:initVar( 'vf', LrView.osFactory(), reloading )
    gbl:initVar( 'bind', LrView.bind, reloading )
    gbl:initVar( 'share', LrView.share, reloading )
    

    
    --   G L O B A L   C L A S S E S
    gbl:initVar( 'String', objectFactory:frameworkModule( 'Data/String' ), reloading ) -- required.
    gbl:initVar( 'Boolean', objectFactory:frameworkModule( 'Data/Boolean' ), reloading ) -- not sure, but its tiny.
    gbl:initVar( 'Number', objectFactory:frameworkModule( 'Data/Number' ), reloading ) -- ditto
    gbl:initVar( 'DateTime', objectFactory:frameworkModule( 'Data/DateTime' ), reloading ) -- probably optional, but also: small.
    gbl:initVar( 'Table', objectFactory:frameworkModule( 'Data/Table' ), reloading ) -- required.
    gbl:initVar( 'Disk', objectFactory:frameworkModule( 'FileSystem/Disk' ), reloading ) -- required.
    gbl:initVar( 'Dialog', objectFactory:frameworkModule( 'Gui/Dialog' ), reloading ) -- required.
    gbl:initVar( 'OperatingSystem', objectFactory:frameworkModule( 'System/OperatingSystem' ), reloading ) -- Required.
    if WIN_ENV then
        gbl:initVar( 'Windows', objectFactory:frameworkModule( 'System/Windows' ), reloading )
        gbl:initVar( 'Mac', nil, reloading )
    else
        gbl:initVar( 'Mac', objectFactory:frameworkModule( 'System/Mac' ), reloading )
        gbl:initVar( 'Windows', nil, reloading )
    end
    gbl:initVar( 'Properties', objectFactory:frameworkModule( 'System/Properties' ), reloading ) -- required.
    gbl:initVar( 'Preferences', nil, reloading ) -- optional, but highly recommended if you will support preferences in plugin manager.
    gbl:initVar( 'LogFile', objectFactory:frameworkModule( 'System/LogFile' ), reloading ) -- required.
    -- gbl:initVar( 'Debug', objectFactory:frameworkModule( 'System/Debug' ), reloading ) -- required.
    gbl:initVar( 'Call', objectFactory:frameworkModule( 'System/Call' ), reloading ) -- required.
    gbl:initVar( 'Service', objectFactory:frameworkModule( 'System/Service' ), reloading ) -- optional - needed for exports or substantial menu initiated services...
    gbl:initVar( 'User', objectFactory:frameworkModule( 'System/User' ), reloading ) -- required.
    gbl:initVar( 'App', objectFactory:frameworkModule( 'System/App' ), reloading ) -- required.
    gbl:initVar( 'Manager', objectFactory:frameworkModule( 'Gui/Manager' ), reloading ) -- required.
    gbl:initVar( 'Catalog', objectFactory:frameworkModule( 'Catalog/Catalog' ), reloading )
    gbl:initVar( 'Gui', objectFactory:frameworkModule( 'Gui/Gui' ), reloading )
    gbl:initVar( 'View', objectFactory:frameworkModule( 'Gui/View' ), reloading )
    gbl:initVar( 'DebugScript', objectFactory:frameworkModule( 'System/DebugScript' ), reloading )
    
    
    
    --   O P T I O N A L   D E P E N D E N C I E S
    -- *** GEN_BEGIN globals
    gbl:initVar( 'XmlRpc', objectFactory:frameworkModule( 'Communication/XmlRpc' ), reloading ) -- user can specify option independently of xml-rpc update option.
    gbl:initVar( 'Export', objectFactory:frameworkModule( 'ExportAndPublish/Export' ), reloading )
    gbl:initVar( 'Preferences', objectFactory:frameworkModule( 'System/Preferences' ), reloading )
    gbl:initVar( 'Background', objectFactory:frameworkModule( 'System/Background' ), reloading )
    gbl:initVar( 'Reload', objectFactory:frameworkModule( 'System/Reload' ), reloading ) -- ###3 build into plugin generator?
    -- *** GEN_END
    
    
    
    --   G L O B A L   O B J E C T S
    -- gbl:initVar( 'dbgr', objectFactory:newObject( Debug ), reloading )
    gbl:initVar( 'props', objectFactory:newObject( Properties ), reloading )
    gbl:initVar( 'fso', objectFactory:newObject( Disk ), reloading )
    gbl:initVar( 'app', objectFactory:newObject( App ), reloading )
    gbl:initVar( 'dialog', objectFactory:newObject( Dialog ), reloading )
    gbl:initVar( 'view', objectFactory:newObject( View ), reloading )
    gbl:initVar( 'cat', objectFactory:newObject( Catalog ), reloading )
    gbl:initVar( 'bool', objectFactory:newObject( Boolean ), reloading )
    gbl:initVar( 'date', objectFactory:newObject( DateTime ), reloading )
    gbl:initVar( 'num', objectFactory:newObject( Number ), reloading )
    gbl:initVar( 'str', objectFactory:newObject( String ), reloading )
    gbl:initVar( 'tab', objectFactory:newObject( Table ), reloading )
    gbl:initVar( 'gui', objectFactory:newObject( Gui ), reloading )
    if gbl:getValue( "Xml" ) then
        gbl:initVar( 'xml', objectFactory:newObject( Xml ), reloading )
    end
    local url = app:getInfo( 'xmlRpcUrl' )
    if url then
        if not gbl:getValue( "XmlRpc" ) then
            gbl:initVar( 'XmlRpc', objectFactory:frameworkModule( 'Communication/XmlRpc' ), reloading )
            gbl:initVar( 'xmlRpc', objectFactory:newObject( XmlRpc, { url=url } ), reloading )
        else
            gbl:initVar( 'xmlRpc', objectFactory:newObject( XmlRpc, { url=url } ), reloading )
        end
    end
    if gbl:getValue( "Reload" ) then
        gbl:initVar( 'reload', objectFactory:newObject( Reload ), reloading )
    end

    
    
    --   S Y N C H R O N O U S   I N I T I A L I Z A T I O N   A N D   S T A R T U P   . . .
    app:checkSupport() -- silent if author's specified platform + lr support matches host & lr version. ###2 really this should be done in very beginning with no dependencies!
    app:init() -- complete synchronous initialization, once platform support confirmed.
    app:initGlobalPref( 'autoUpdateCheck', false, reloading )
    app:initGlobalPref( 'advDbgEna', false, reloading )
    app:initGlobalPref( 'classDebugEnable', false, reloading )
    app:initGlobalPref( 'classDebugSynopsis', "", reloading )
    app:initGlobalPref( 'logVerbose', false, reloading )
    if app:getGlobalPref( 'advDbgEna' ) then
        Debug.init( true )
    else
        Debug.init( false )
    end
    if app:getGlobalPref( 'autoUpdateCheck' ) then
        app:checkForUpdate( true ) -- true means silent if up-to-date.
    end

    if reloading then
        app:logInfo( "Framework reloaded." )
    else
        app:logInfo( "Framework initialized.", App.verbose )
    end
    gbl:initVar( 'reloading', false, reloading )
    
end



return Init