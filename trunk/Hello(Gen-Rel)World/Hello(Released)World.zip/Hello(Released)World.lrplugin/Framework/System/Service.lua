--[[
        Service.lua
        
        A service is an operation with an associated log file.
--]]

local Service, dbg = Call:newClass{ className = "Service" }



--- Constructor for extending class.
--
function Service:newClass( t )
    return Call.newClass( self, t )
end



--- New instance constructor.
--      
--  @param      t   Parameter table whose elements are:
--                  <ul>
--                  <li>name: (string) required<br>
--                  <li>object: (table) instance of class with main and finale methods - optional.<br>
--                  <li>main: (function) required.<br>
--                  <li>async: (boolean) nil or false => synchronous.<br>
--                  <li>finale: (function) executed after main - optional.<br>
--                  <li>guard:  (number) nil => none, App.guardSilent => silent, App.guardVocal => vocal.</ul>
--
--  @return     service object suitable for passing to app:call method.
--
function Service:new( t )
    
    local o = Call.new( self, t )
    if o.logFilePath == nil then
        o.logFilePath = _PLUGIN.id .. ".LogFile.txt"
    else
        -- 
    end
    return o
end



--- Initiate and perform main service function, excluding the finale.
--
--  <p>See Call parent class for more info.</p>
--
--  @param  context     function-context, in case you need to create a property table, hopefully thats the only use for it...
--  @param  ...         Passed to main.
--
function Service:perform( context, ... )

    -- app:showInfo( "Doin service" )
    dbg( "Doin service: ", self:getFullClassName() )

    self.startTime = LrDate.currentTime()
    local dateTimeFormat = '%Y-%m-%d %H:%M:%S'
    local startTimeFormatted = LrDate.timeToUserFormat( self.startTime, dateTimeFormat )
    
    self.startErrors = app:getErrorCount()
    self.startWarnings = app:getWarningCount()

    if app:isLoggerEnabled() then

        app:logInfoToBeContinued( str:format( "^1 started ^2", self.name, startTimeFormatted ) )
        if app:isTestMode() then
            app:logInfoToBeContinued( " IN TEST MODE\n- TEST MODE: Theoretically no files were actually created, modified, or deleted.\n" )
        else
            app:logInfoToBeContinued( " IN REAL MODE\n- REAL MODE: Theoretically, files were actually created, modified, or deleted, as indicated.\n" )
        end
    
        if app:isVerbose() then
            app:logInfo( "Logging verbosely." )
            app:logInfo( "Plugin Name: " .. app:getPluginName() )
            app:logInfo( "Plugin Version: " .. app:getVersionString() )
            app:logInfo( "Lightroom Version: " .. LrApplication.versionString() )
            app:logInfo( "Platform: " .. app:getPlatformName() )
            app:logInfo( "Compatibility: " .. app:getCompatibilityString() )
    
            -- app no longer supports "support files". - Leaving in for nostalgia...
            --[[app:logInfo( "Support files may be specified absolutely or relative to these places, tried in this order:" )
            app:logInfo( "Catalog: " .. LrApplication.activeCatalog().path )
            app:logInfo( "Plugin parent: " .. LrPathUtils.parent( _PLUGIN.path ) )
            app:logInfo( "Plugin proper: " .. _PLUGIN.path )
            -- 'home', 'documents', 'appPrefs', 'desktop', 'pictures': must match order in app class.
            app:logInfo( "Home: " ..  LrPathUtils.getStandardFilePath( 'home' ) )
            app:logInfo( "Documents: " ..  LrPathUtils.getStandardFilePath( 'documents' ) )
            app:logInfo( "Application Preferences: " ..  LrPathUtils.getStandardFilePath( 'appPrefs' ) )
            app:logInfo( "Desktop: " ..  LrPathUtils.getStandardFilePath( 'desktop' ) )
            app:logInfo( "Pictures: " ..  LrPathUtils.getStandardFilePath( 'pictures' ) )--]]
            -- *** My experience has been the default directory would actually be c:/windows/system32 yet the default directory is
            -- being shown as '/'. Since this is misleading, and only reluctantly supported (will return file relative to
            -- default if found but accompanied by a warning), suppress logging of default dir.
        else
            app:logInfo( "Logging non-verbosely." )
        end
    
        app:logInfo()
        app:logInfo("Plugin path: " .. _PLUGIN.path .. '\n\n' )
       
    end
    
    Call.perform( self, context, ... )
    
end



--- Perform finale...
--
--  <p>See Call parent class for more info.</p>
--
--  @param      status      boolean: true iff execution completed without an error being thrown.
--  @param      message     string: error message corresponding to error if thrown.
--
function Service:cleanup( status, message )

    -- local s,m = LrTasks.pcall( Call.finale, self, status, message ) -- calls registered finale method.
    Call.cleanup( self, status, message ) -- calls regstered finale method.
    
    if status then
        -- dbg( "cleanup for good" )
    else
        app:logError( message or "Unknown error." )
        self:abort("Aborted due to error.") -- but continue to display log footer / status.
    end
    
    -- errors in this part are caught by App which will call default error handler.
    
    self.stopTime = LrDate.currentTime()
    local elapsedTimeFormatted = date:formatTimeDiff( self.stopTime - self.startTime )
    self.startTime = nil -- closes the service/export so end-service can be called redundently with impunity.
    
    local nErrors = app:getErrorCount() - self.startErrors -- number of app errors logged while this service was processing.
    local nWarnings = app:getWarningCount() - self.startWarnings -- ditto - warnings.

    local dateTimeFormat = '%Y-%m-%d %H:%M:%S'
    local stopTimeFormatted = LrDate.timeToUserFormat( self.stopTime, dateTimeFormat )

    app:logInfo( '\n\n\n' )
    app:logInfo( str:format( "^1 finished at ^2 (^3 seconds).\n\n\n\n\n", self.name, stopTimeFormatted, elapsedTimeFormatted ) )
	
    -- present final dialog box message:
    local message = nil
    local prefix = ''
    prefix = self.name .. ' '
    if not self:isAborted() then
        if nErrors == 0 then
            message = prefix .. ' - all done (no errors).\n'
        else
            message = prefix .. " - done, but " .. str:plural( nErrors, " error" ) ..".\n" 
        end
    else
        -- progress scope has been cancelled.
        if nErrors == 0 then
            message = prefix .. ' - quit early (but no errors). Reason: ' .. self:getAbortMessage() .. '\n'
        else
            message = prefix .. " - quit early, and " .. str:plural( nErrors, " error" ) ..".\n" 
        end
    end
    if nWarnings > 0 then
        message = message .. str:plural( nWarnings, " warning" ) ..".\n" 
    end

	if app:isLoggerEnabled() then
		message = message .. str:format( "See log file for details: ^1", app:getLogFilePath() )
	else
		message = message .. str:format( "No log file was created." )
	end

    -- present final dialog box.
    local actionPrefKey
    local buttons = nil
    if nErrors == 0 and nWarnings == 0 and app:isRealMode() then
        actionPrefKey = app:getAppName() .. " - AllDoneFinalDialogViewLog"
        if app:isLoggerEnabled() then
            buttons = { { label="Skip Log File", verb='skip' }, { label="View Log File", verb='ok' } }
        end
    else
        actionPrefKey = nil
        if app:isLoggerEnabled() then
            buttons = 'View Log File'
        end
    end

    local action = app:showInfo( message, actionPrefKey, buttons ) -- no longer using error/warning specific dialog boxes for final presentation
        -- in honor of view-log-file upgrade.
    if action=='ok' then -- seems like this used to die if left hand was nil, but it doesn't die now.
        if app:isLoggerEnabled() and LrFileUtils.exists( app:getLogFilePath() ) then
            app:showLogFile()
        else
            dbg( "no log" )
        end
    else
       -- dbg( "notokforlogs" )
    end
    

end



return Service