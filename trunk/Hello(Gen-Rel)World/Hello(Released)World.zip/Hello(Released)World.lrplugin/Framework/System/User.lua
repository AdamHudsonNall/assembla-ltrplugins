--[[
        User Manager
        
        Supports multi-user plugins.
--]]



local User = Object:newClass{ className = 'User' }



--- Constructor for extending class.
--
function User:newClass( t )
    return Object.newClass( self, t )
end



--- Create user object.
--      
--  <p>User's name is obtained from shared property file.</p>
--      
--  @return            user object instance.
--
function User:new( t )

    local o = Object.new( self, t ) -- create generic new object, or add "object-ness" to user table.
    o.name = props:getSharedProperty( "user" )
    return o
    
end



--- Determine if there is a non-anonymous user active.
--      
--  @return     boolean: true iff user not anonymous.
--
function User:is()
    return str:is( self.name )
end



--- Get's user name for display/logging, or decision making.
--
--  @usage      Use 'is' method first if you want to distinguish between "real user" and "anonynmous".
--
--  @return     string: Real user name if applicable, else something indicating anonymous user, presently '_Anonymous_'.
--
function User:getName()
    return self.name or '_Anonymous_'
end



return User        

