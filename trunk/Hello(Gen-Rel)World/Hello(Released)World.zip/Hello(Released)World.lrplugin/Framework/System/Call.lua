--[[
        Call.lua
        
        A glorified pcall, which uses cleanup handlers, and assures at least default error handling.
        
        Benefits include extensibility for calls that go beyond the simplest case, wrapping
        
        basic functionality with more elaborate start / cleanup code (see 'Service' class as example).
--]]


local Call, dbg = Object:newClass{ className = "Call" }



--- Constructor for class extension.
--
function Call:newClass( t )
    return Object.newClass( self, t )
end



--- Constructor for new instance objects.
--      
--  <p>Table parameter elements:</p><blockquote>
--      
--          - name:         operation name, used for context debugging and as guard key.<br>
--          - async:        nil or false => synchronous, true => runs as asynchronous task.<br>
--          - guard:        0 or nil => no guard, 1 => silent, 2 => vocal.<br>
--          - object:       if main (and cleanup if applicable) is method, object is required, else leave blank to call main (and cleanup if applicable) as static function.<br>
--          - main:         main function or method - required.<br>
--          - cleanup:      if something to do after main completes or aborts.</blockquote>
--
--  @param  t               Table holding call paramaters.
--
function Call:new( t )
    
    if not t then
        error( "Call constructor requires parameter table." )
    elseif not t.name then
        error( "Call constructor requires name in parameter table." )
    elseif not t.main then
        error( "Call requires main function in parameter table." )
    end
    if app:isAdvDbgEna() then -- make sure its unwrapped if not debugging, since finale handlers depend on it.
        t.main = Debug.showErrors( t.main )
    end
    local o = Object.new( self, t )
    o.abortMessage = ''
    return o
end



--- Abort call or service.
--
--  @usage Note: Do not call base class abort method here.
--
function Call:abort( message )
    if str:is( message ) then
        self.abortMessage = message -- serves as boolean indicating "is-aborted" as well as providing the message.
    else
        self.abortMessage( "unable to ascertain reason for abort" )
    end
end



--- Determine if call has been aborted.
--
function Call:isAborted()
    return str:is( self.abortMessage )
end



-- Get abort message for display.
--
-- @return empty string if not aborted.
--
function Call:getAbortMessage()
    return self.abortMessage or ''
end



--- Call (perform) main function.
--
--  @usage          Called as static function if object nil, else method.
--  @usage          Errors thrown in main are caught by App and passed to finale.
--
function Call:perform( context, ... )
    self.abortMessage = ''
    self.context = context
    if self.object then
        self.main( self.object, self, ... )
    else
        self.main( self, ... )
    end
end



--- "Cleanup" function called after main function, even if main aborted due to error.
--
--  <p>I'm not real crazy about the term "cleanup", but the big deal is that its guaranteed to be called
--  regardless of the status of main function execution. "cleanup" activities can include things like
--  clearing recursion guards, logging results, and displaying a successful completion or error message.</p>
--
--  @usage          App calls this in protected fashion - if error in cleanup function, default error handler is called.
--
function Call:cleanup( status, message )
    if self.finale then
        if self.object then
            self.finale( self.object, self, status, message )
        else
            self.finale( self, status, message )
        end
    elseif status then
        -- no finale func/method, but main func executed without error - good enough...
    else
        app:defaultFailureHandler( false, message )
    end
end



return Call