--[[
        App:lua
        
        Design priniciple:
        
        App object methods implement primary API between derived plugin classes and app-framework/system.
        
        The idea is: as much as possible, to have a one-obj interface that will not have to change,
        despite potentially extensive changes in the code that implements the framework.
        
        For example, plugins don't interface directly to the preferences, since the preference object / methods may change,
        The app interface for preferences however should not change (as much...).
--]]


local App, dbg = Object:newClass{ className= 'App' }

App.guardNot = 0
App.guardSilent = 1
App.guardVocal = 2
App.verbose = true


--- Constructor for extending class.
--
--  @param      t       initial table - optional.
--
function App:newClass( t )
    return Object.newClass( self, t )
end



--- Constructor for new instance object.
--      
--  @param      t       initial table - optional.
--
--  @usage      Called from init-lua once all globals have been initialized.
--  @usage      Reads info-lua and creates encapsulated worker-bee objects.
--
function App:new( t )

    local o = Object.new( self, t )

    o.guards = {}
    o.guarded = 0
        
    -- app-wide error/warning stats. Cleared when log cleared, even if no log file.
    -- service saves these to display difference at end-of-service.
    o.nErrors = 0
    o.nWarnings = 0

    -- read info-lua
    local status
    local status, infoLua = pcall( dofile, LrPathUtils.child( _PLUGIN.path, "Info.lua" ) )
    if status then
        o.infoLua = infoLua
    else
        error( infoLua )
    end
    
    math.randomseed( LrDate.currentTime() )

    if LogFile ~= nil then -- log file support is optional, but if logging, its first order of business,
        -- so other things can log stuff as they are being constructed / initialized.
        o.logr = objectFactory:newObject( LogFile )
        o.logr:enable{ verbose = ( prefs.logVerbose or prefs._global_logVerbose ) } -- ###2 could be smoother.
        if o.logr.verbose then
            o.logr:logInfo( "Logger enabled verbosely." )
        else
            o.logr:logInfo( "Logger enabled." )
        end
    end
    o.user = objectFactory:newObject( User )
    if Preferences then
        o.prefMgr = objectFactory:newObject( Preferences )
    end
    o.os = objectFactory:newObject( 'OperatingSystem' )
    
    -- dbg( "ima plugin: ", "arn't i" )
    return o

end



--- Synchronous initialization
--
--  @usage      Called from Init.lua - initialization done here should be relatively quick and not yield or sleep, to eliminate race conditions between
--              startup and intiation of asynchronous services. Use background task for asynchronous initialization ( with post-init termination if nothing periodic/in-the-background to do ).
--
function App:init()

    -- supports binding to windows / mac specific things in the UI:
    if WIN_ENV then
        self:setGlobalPref( "Windows", true ) -- for binding to things that depend on platform.
        self:setGlobalPref( "Mac", false )
    else
        self:setGlobalPref( "Mac", true )
        self:setGlobalPref( "Windows", false )
    end
    
    self:switchPreset() -- assures presets are initialized before any asynchronous service accesses them.
end



--- Determines if plugin is in release state.
--
--  @usage      Its considered a release state if plugin extension is "lrplugin".
--
function App:isRelease()
    return LrPathUtils.extension( _PLUGIN.path ) == 'lrplugin'
end



--- Determines if plugin can support Lr3 functionality.
--      
--  @usage          Returns false in Lr1 & Lr2, true in Lr3, will still return true in Lr4 (assuming deprecated items persist for one & only one version), false in Lr5.
--
function App:isLr3()
    local lrVerMajor = LrApplication.versionTable().major
    if LrApplication.versionTable ~= nil then
        return lrVerMajor >= 3 and lrVerMajor <= 4
    else
        return false
    end
end



--- Is app operating in verbose/debug mode, or normal.
--
function App:isVerbose()
    return app:getGlobalPref( 'logVerbose' )
end



--- Test mode detection.
--  
--  <p>Test mode was invented to support test-mode plugin operation, and especially file-ops (rc-common-modules), which were guaranteed not to modify any files unless real mode.
--  For better or for worse, this functionality has been dropped from disk file-system class, but could still be used on an app-by-app basis.</p>
--
--  @usage      If test-mode functionality is desired, then set up a UI and bind to test-mode as global pref.
--
function App:isTestMode()
    return app:getGlobalPref( 'testMode' ) or false
end



--- Real mode detection.
--      
--  <p>Convenience function for readability: opposite of test mode.</p>
--
--  @see        App:isTestMode
--
function App:isRealMode()
    return not self:isTestMode()
end



--- Create a new preference preset.
--
function App:createPreset( props )
    if self.prefMgr then
        self.prefMgr:createPreset( props )
    end
end



--- Switch to another preference preset.
--
function App:switchPreset( props )
    if self.prefMgr then
        self.prefMgr:switchPreset( props )
    end
end



--- Set global preference.
--
--  @param name pref name
--  @param val pref value
--
--  @usage use this instead of setting directly, to make sure the proper key is used.
--
function App:setGlobalPref( name, val )
    if self.prefMgr then
        self.prefMgr:setGlobalPref( name, val )
    else
        prefs[name] = val -- bypasses global prefix if no pref manager.
    end
end



--- Get global preference.
--
--  @param name pref name
--
--  @usage use this instead of setting directly, to make sure the proper key is used.
--
function App:getGlobalPref( name )
    if self.prefMgr then
        return self.prefMgr:getGlobalPref( name )
    else
        return prefs[name] -- bypasses global prefix if no pref manager.
    end
end



--- Get binding that uses the proper key.
--
--  <p>UI convenience function that combines getting a proper global preference key, with creating the binding...>/p>
--
--  @param name pref name
--  @param val pref value
--
--  @usage use this for convenience, or bind directly to get-global-pref-key if you prefer.
--
function App:getGlobalPrefBinding( name )
    local key = self:getGlobalPrefKey( name )
    return bind( key )
end



--- Init global preference.
--
--  @param name global pref name.
--  @param dflt global pref default value.
--
--  @usage a-kin to init-pref reglar, cept for global prefs...
--
function App:initGlobalPref( name, dflt )
    if not str:is( name ) then
        error( "Global preference name key must be non-empty string." )
    end
    if self.prefMgr then
        self.prefMgr:initGlobalPref( name, dflt )
    elseif prefs then
        if prefs[name] == nil then
            prefs[name] = dflt
        end
    else
        error( "No prefs." )
    end
end



--- Get global preference key for binding.
--
--  @param name global pref name.
--
--  @usage not usually needed since there's get-global-pref-binding function,
--         <br>but this is still needed for binding section synopsis's.
--
function App:getGlobalPrefKey( name )
    if self.prefMgr then
        return self.prefMgr:getGlobalKey( name )
    else
        return name -- bypasses global prefix if no pref manager.
    end
end



--- Preset name change handler.
--
--  @usage  Preferences module may be assumed if preset name is changing.
--
--  @usage  Wrapped externally.
--
function App:presetNameChange( props, name, value )
    local presetName = self.prefMgr:getPresetName()
    if str:is( value ) and presetName ~= 'Default' then
        if self.prefMgr:isPresetExisting( value ) then -- go through App?
            self:switchPreset( props ) -- creates new set with backing file if appropriate then loads into props.
            dialog:showInfo( "Preferences switched to preset: " .. value, "NamedPrefSetSwitched" )
        else
            if dialog:isOk( str:format( "Create a new preset named '^1'?", presetName ) ) then
                self:createPreset( props ) -- creates new set with backing file if appropriate then loads into props.
                dialog:showInfo( "New preset created: " .. value, "NewNamedPrefSet" )
            else
                app.prefMgr:setGlobalPref( 'presetName', '' ) -- gotta get rid of new value, but its been pre-commited (dunno what it used to be).
                self:switchPreset( props )
                dialog:showInfo( "Reloaded un-named preset.", "UnnamedPrefsLoaded" )
            end
        end
    else
        self.prefMgr:setGlobalPref( 'presetName', '' ) -- in case its not already (will not trigger recursion, since silently guarded).
        self:switchPreset( props )
        dialog:showInfo( "Reverted to un-named preset.", "UnnamedPrefsLoaded" )
    end
end



--- Clear all preferences for this plugin.
--
--  @usage Generally only called in response to button press when adv-dbg-enabled and prefs are managed.
--         <br>but could be called in init-lua or wherever if you like - for testing and debug only...
--
--  @usage Works for managed as well as un-managed preferences.
--
function App:clearAllPrefs( props )
    for k,v in prefs:pairs() do -- note: nil prefs are not delivered by pairs function.
        prefs[k] = nil
    end
    for k,v in props:pairs() do -- note: nil prefs are not delivered by pairs function.
        props[k] = nil
    end
end



--- Loads (plugin manager) properties from named set or unnamed.
--      
--  @param      props       The properties to load.
--
--  @usage      Handles case when preference preset manager is installed, or not.
--
function App:loadProps( props )

    if self.prefMgr then
        self.prefMgr:loadProps( props )
    else
        -- this stolen from preferences-lua.
        for k,v in prefs:pairs() do
            local p1, p2 = k:find( '__', 1, true )
            if p1 and ( p1 > 1 ) then
            else
                -- dbg( "loading unnamed pref into prop: ", str:format( "prop-name: ^1, val: ^2", k, str:to( v ) ) )
                if k == 'testData' then
                    dbg( "loading unnamed test data preference into property" )
                end                    
                props[k] = v -- note: this will pick up all the globals too, but hopefully won't matter, since they won't be on the view.
            end
        end
    end

end



--- Save properties in preferences.
--      
--  @param      props       The properties to save.
--
--  @usage      file-backing is read-only.
--  @usage      As coded, this only applies to named presets when preset-name property changes.
--
function App:saveProps( props )

    if self.prefMgr then
        self.prefMgr:saveProps( props )
    else
        -- ###3 - presently all are saved in manager using setpref.
    end

end



--- Get number of errors logged since logger was cleared (or app startup).
--
function App:getErrorCount()
    return self.nErrors
end



--- Get number of warnings logged since logger was cleared (or app startup).
--
function App:getWarningCount()
    return self.nWarnings
end



--- Get log file contents as text string.
--
--  <p>Invented to support Dialog function (kluge) to copy log contents to clipboard.</p>
--
function App:getLogFileContents()
    if self.logr then
        return self.logr:getLogContents()
    else
        return nil, "No logger."
    end
end



---     Not usually needed, since show-log-file and send-log-file are both app interfaces.
--      
--      In any case, it may be handy...
--
function App:getLogFilePath()
    if self.logr then
        return self.logr:getLogFilePath()
    else
        return nil
    end
end



---     Determines if advanced debug functionality is present and enabled.
--      
--      May be useful externally before embarking in time consuming loops that are no-op if not enabled.
--
function App:isAdvDbgEna()
    -- if self.advDbg and self:getGlobalPref( 'advDbgEna' ) then
    if self:getGlobalPref( 'advDbgEna' ) then
        return true
    else
        return false
    end
end



---     Shows log file to user by opening in default app for .log.
--      
--      I assume if no default set up, the OS will prompt user to do so(?)
--
function App:showLogFile()

    if self:isLoggerEnabled() then
        local logFile = self.logr:getLogFilePath()
        if fso:existsAsFile( logFile ) then
            self.os:openFileInDefaultApp( self.logr:getLogFilePath() )
        else
            self:showInfo( "There are no logs to view (log file does not exist)." )
        end        
    else
        self:showInfo( "There is no log file to show." )
    end

end



---     Clear the contents of the log file and the logged error/warning counts.
--
function App:clearLogFile()

    self.nErrors = 0
    self.nWarnings = 0

    if self:isLoggerEnabled() then
        self.logr:clear()
    else
        self:showInfo( "There is no log file to clear, nevertheless: error+warning counts have been zeroed." )
    end

end



--- Show info to user - OK to just use dialog method directly if desired.
--
--  @usage      See Dialog class for param descriptions.
--
function App:showInfo( info, actionPrefKey, buttons, cancelButton, otherButton )
    return dialog:showInfo( info, actionPrefKey, buttons, cancelButton, otherButton )
end



--- Show warning to user - OK to just use dialog method directly if desired.
--
--  @usage      See Dialog class for param descriptions.
--
function App:showWarning( info, b1, b2, b3 )
    return dialog:showWarning( info, b1, b2, b3 )
end



--- Show error to user - OK to just use dialog method directly if desired.
--
--  @usage      See Dialog class for param descriptions.
--
function App:showError( info, b1, b2, b3 )
    return dialog:showError( info, b1, b2, b3 )
end



--- Determine if app has a logger that can be used.
--      
--  <p>Purpose is to circumvent log loops or other functionality
--  that only makes sense if there is a logger.</p>
--      
--  <p>Presently it does not indicate if the logger is enabled for logging or not,
--  however, if there is a logger, then it is enabled - for now. - Non-logging plugins
--  are not even supported. But they don't have to log anything they don't want to,
--  so it does not have to slow them down much - still the future may change this.</p>
--
function App:isLoggerEnabled()
    return self.logr ~= nil
end



--- Open file in OS default app.
--
-- <p>App is chocked full of convenience functions like this one.</p>
--
--  @param file     The file to open.
--
--  @usage  Presently supports just one file, but could be enhanced to support multiple files.
--
function App:openFileInDefaultApp( file )
    self.os:openFileInDefaultApp( file )
end



--- Get OS platform name.
--
--  @return     'Windows' or 'Mac'.
--
function App:getPlatformName()
    if WIN_ENV then
        return 'Windows'
    else
        return 'Mac'
    end
end



--- Determine if non-anonymous user.
--      
--  @return     boolean
--
function App:isUser()
    return self.user:is()
end



--- Get name of user.
--      
--  <p>Note: There is no API for entering a user name,
--  however it will be read from shared properties when available.</p>
--      
--  <p>It used to be critical before named preferences came along, now
--  its just there in case you want to alter logic slightly depending
--  on user name - I sometimes customize behavior for myself, that other
--  users will never see...</p>
--      
--  <p>You could make custom versions for a friend or client that does not
--  require a separate plugin nor named preference set.</p>
--
--  @return     user's name: typically "_Anonymous_" if none.
--
function App:getUserName()
    return self.user:getName()
end



--- Executes a shell command.
--
--  <p>Although the format for command/params... is platform independent, the command itself may not be. For example:</p>
--  <blockquote>'exiftool' may be all that is needed to reference a pre-installed version of exiftool on Mac. However, full path may be required on windows,
--  since exiftool installer does not automatically add exiftool to path.</blockquote>
--
--  @param          command         A pathed command name, or absolute path to executable.
--  @param          parameters      Example string: '-G -p "asdf qwerty"'
--  @param          targets         An array of filenames.
--  @param          output          Path to file where command output will be re-directed, or nil for let method decide.
--  @param          outHandling     nil or '' => do nothing with output, 'get' => retrieve output as string, 'del' => retrieve output as string and delete output file.--
--  @usage          Quotes will be added where necessary depending on platform. The only exception to this is when something in parameter string needs to be quoted.
--
--  @usage          calling context can choose to alter parameters based on user and/or debug mode in order to keep output file(s) for perusal if desired.
--
--  @return         status (boolean):       true iff successful.
--  @return         command-or-error-message(string):     command if success, error otherwise.
--  @return         content (string):       content of output file, if out-handling > 0.
--
function App:executeCommand( command, parameters, targets, output, handling )
    return self.os:executeCommand( command, parameters, targets, output, handling )
end



--- Call an operation, with optional variable parameters.
--
--  <p>See 'Call' and 'Service' classes for more information.</p>
--
--  @param      op      Derived from the 'Call' class.<br><br>
--      
--          Reminder, must include:<br><ul>
--      
--              <li>name
--              <li>main (called as method if object passed)
--              <li>(object - if main is a method)<br><br></ul>
--          
--          Optional:<br><ul>
--          
--              <li>cleanup (also called as method if object passed).
--              <li>async
--              <li>guard</ul><br>
--
--  @param      ...     Passed to main function.
--
function App:call( op, ... )

    local param = { ... }
    
    if op.guard then
        if self.guards[op.name] then
            if op.guard == self.guardSilent then
                self.guarded = self.guarded + 1
                return
            else
                self:showWarning( op.name .. " already started." )
                return
            end
        else
            self.guards[op.name] = true
        end
    end
    
    -- note: new way is for app to always call the op's cleanup methods, which
    -- will decide whether to call a default, or method vs. static...
    local cleanup = function( status, message )
        if op.guard then
            self.guards[op.name] = nil
        end
        LrFunctionContext.callWithContext( "app-call-cleanup", function( context )
            context:addFailureHandler( self.defaultFailureHandler )
            op:cleanup( status, message )
        end )
    end
    
    if op.async then
        LrFunctionContext.postAsyncTaskWithContext( op.name, function( context )
            -- context:addFailureHandler( failure ) - no need for failure handler if you've got a cleanup handler
            context:addCleanupHandler( cleanup )
            op:perform( context, unpack( param ) )
        end )
    else
        LrFunctionContext.callWithContext( op.name, function( context )
            -- context:addFailureHandler( failure ) - no need for failure handler if you've got a cleanup handler
            context:addCleanupHandler( cleanup )
            op:perform( context, unpack( param ) )
        end )
    end
end



--- Start or continue log entry, without terminating it.
--
--  @usage      Useful for starting a log line at the entrance to some code block, then finishing it upon exit, depending on status...
--
function App:logInfoToBeContinued( message )
    if self.logr then
        self.logr:logInfoStart( message )
    end
end


--- Log info (will append to whatever was "to-be-continued").
--
--  @param message informational message
--  @param verbose set to App.verbose if the message should only be emitted if verbose logging is enabled.
--
function App:logInfo( message, verbose )
    if self.logr then
        self.logr:logInfo( message, verbose )
    end
end



--- Count warning and log it with number.
--
function App:logWarning( message )
    self.nWarnings = self.nWarnings + 1
    if self.logr then
        self.logr:logWarning( self.nWarnings, message )
    end
end



--- Count error and log it with number.
--
function App:logError( message )
    self.nErrors = self.nErrors + 1
    if self.logr then
        self.logr:logError( self.nErrors, message )
    end
end



--  Background:             How Lightroom handles errors in plugins:<br><br>
--      
--                          - if error occurs, then check if there is a registered handler,<br>
--                            if so, then call it, if not - do nothing.<br><br>
--                            
--                          - button handlers operate in contexts that do not have error handlers<br>
--                            registered.<br><br>
--
--  Notes:                  - This default failure handler, should be used "instead" of a pcall, in cases<br>
--                            where you you just want to display an error message, instead of croaking<br>
--                            with the default lightroom error message (e.g. normal plugin functions),<br>
--                            or dieing siliently (e.g. button handlers).<br></p>
--
--- Failure handler which can be used if nothing better springs to mind.
--      
--  @param      _false      First parmameter is always false and can be safely ignored.
--  @param      errMsg      Error message.
--
--  @usage                  Generally only used when there is no cleanup handler.
--
function App:defaultFailureHandler( _false, errMsg )
    local msg = str:to( errMsg ) .. ".\n\nPlease report this problem - thank you in advance..."
    LrDialogs.message( ( self:getAppName() or _PLUGIN.id ) .. " has encountered a problem.", "Error message: " .. msg )
end



--- Get default failure handling function.
--
--  <p>@2010-11-21 - not used, but available just the same.</p>
--
function App:getDefaultFailureHandler()
    return self.defaultFailureHandler
end



---     Gets app name, which in general is the same as plugin name,
--      although I have run into cases where I wanted them to be a little different.
--      - your call.
--
function App:getAppName()
    if self.infoLua.appName then
        return self.infoLua.appName
    else
        return self:getPluginName()
    end
end



--- Get plugin version number as a string.
--
--  <p>Preferrably without the build suffix, but manageable even with...</p>
--
--  @usage       Correct functioning depends on compatible VERSION format, which is either:
--
--               <p>- major/minor/revision, or
--               <br>- {version-number-string}{white-space}{build-info}</p>
--
--               <p>Plugin generator & releasor generate compatible version numbers / string format.
--               <br>If you are using an other build/release tool, just make sure the xml-rpc-server recognizes
--               <br>the value returned by this method and all should be well.</p>
--               
--               <p>Even if build is tossed in with version number due to omission of expected white-space
--               <br>it will still work as long as xml-rpc-server understands this...</p>
--               
--  @usage       It is up to the xml-rpc-server implementation to make sure if there is a version mismatch
--               between client version and server version, that the server version is always considered "newest".
--
--               <p>In other words, a string equality comparison is done, rather than a numerical version comparison,
--               <br>to determine whether the server version shall be considered "newer".</p>
--
--  @return      Unlike some similarly named app methods, the value returned by this one is used
--               <br>not only for UI display but for checking version number on server via xml-rpc.
--
--               <p>Returns "unknown" if not parseable from info-lua-VERSION...</p>
--
function App:getVersionString()
    local ver
    if self.infoLua.VERSION then
        if self.infoLua.VERSION.major then -- minor + revision implied.
            ver = '' .. self.infoLua.VERSION.major .. '.' .. self.infoLua.VERSION.minor
            if self.infoLua.VERSION.revision > 0 then
                ver = ver .. '.' .. self.infoLua.VERSION.revision
            end
        else -- display is mandatory if no major/minor/revision.
            local split = str:split( self.infoLua.VERSION.display, " " )
            ver = split[1]
        end
    end
    if ver then
        return ver
    else
        return "unknown"
    end
end 



--- Get friendly Lr compatibility display string.
--
--  @return              string: e.g. Lr2+Lr3
--
function App:getLrCompatibilityString()

    local infoLua = self.infoLua    
    
    local lrCompat = "Lr" .. infoLua.LrSdkMinimumVersion
    if infoLua.LrSdkVersion ~= infoLua.LrSdkMinimumVersion then
        lrCompat = lrCompat .. " to Lr" .. infoLua.LrSdkVersion
    else
        -- lrCompat = lrCompat .. " only" -- trying to say too much - may make user think it won't work with dot versions.
        -- Note: an older version of Lightroom won't load it if min ver too high, so the "only" would never show in that case anyway.
        -- Only value then would be on more advanced version of Lightroom. So, its up to the plugin developer to bump that number
        -- once tested on the higher version of Lightroom. Users of higher Lr versions should rightly be concerned until then.
    end
    
    return lrCompat
    
end



--- Get plugin author's name as specified in info-lua.
--
--  @return string: never nil, blank only if explicitly set to blank in info-lua, otherwise something like "unknown".
--
function App:getAuthor()
    return self.infoLua.author or "Unknown" -- new way: set author in info.lua.
end



--- Get plugin author's website as specified in info-lua.
--
--  @return string: never nil, blank only if explicitly set to blank in info-lua, otherwise something like "unknown".
--
function App:getAuthorsWebsite()
    return self.infoLua.authorsWebsite or "Unknown"
end



--- Get plugin url as specified in info-lua.
--
--  @return string: never nil, blank only if explicitly set to blank in info-lua, otherwise something like "unknown".
--
function App:getPluginUrl()
    return self.infoLua.LrPluginInfoUrl or "Unknown"
end



--- Get plugin name as specified in info-lua.
--
--  @return string: required by Lightroom.
--
function App:getPluginId()
    if self.infoLua.pluginId then
        return self.infoLua.pluginId -- overridden.
    else
        return _PLUGIN.id -- standard.
    end
end 



--- Get plugin name as specified in info-lua.
--
--  @return string: required by Lightroom.
--
function App:getPluginName()
    return self.infoLua.LrPluginName or error( "Plugin name must be specified in info-lua." ) -- I don't think we could get this far without it, still...
end 



--- Get friendly string for displaying Platform compatibility - depends on platform support array defined in info-lua.
--
--  @return string: never nil. e.g. Windows+Mac
--
function App:getPlatformString()
    local infoLua = self.infoLua
    if not tab:isEmpty( infoLua.platforms ) then
        return table.concat( infoLua.platforms, "+" )
    else
        return ""
    end
end 



--- Determine if plugin supports Windows OS.
--
--  @return true if definitely yes, false if definitely no, nil if unspecified.
--
function App:isWindowsSupported()
    local infoLua = self.infoLua
    if not tab:isEmpty( infoLua.platforms ) then
        if str:isEqualIgnoringCase( infoLua.platforms[1], 'Windows' ) or str:isEqualIgnoringCase( infoLua.platforms[2], 'Windows' ) then
            return true
        else
            return false
        end
    else
        return nil
    end
end



--- Determine if plugin supports Mac OS.
--
--  @return true if definitely yes, false if definitely no, nil if unspecified.
--
function App:isMacSupported()
    local infoLua = self.infoLua
    if not tab:isEmpty( infoLua.platforms ) then
        if str:isEqualIgnoringCase( infoLua.platforms[1], 'Mac' ) or str:isEqualIgnoringCase( infoLua.platforms[2], 'Mac' ) then
            return true
        else
            return false
        end
    else
        return nil
    end
end



--- Determine if plugin supports current platform.
--
--  @return true if definitely yes, false if definitely no, nil if unspecified.
--
function App:isPlatformSupported()
    local is
    if WIN_ENV then
        is = self:isWindowsSupported()
    else
        is = self:isMacSupported()
    end
    return is
end



--- Determine if plugin supports current Lightroom version.
--
--  @return true iff definitely yes.
--
function App:isLrVersionSupported()
    local infoLua = self.infoLua
    
    local lrVerMajor = LrApplication.versionTable().major
    
    if lrVerMajor <= infoLua.LrSdkVersion then
        -- actual version less than specified version: note this is always OK, since LR would not load if actual version was less than minimimum.
        return true
    else -- lrVerMajor > infoLua.LrSdkVersion 
        -- here's where there is potential for a rub: Lightroom assumes backward compatibility, but I don't - i.e. if Lr is 5 and max Lr is 3, do we really want to run it?
        -- maybe so, and maybe not, but this is what this check is all about...
        return false
    end
end



--- Get Lightroom version name.
--
--  @return e.g. Lr3
--
function App:getLrVersionName()
    local lrVerMajor = LrApplication.versionTable().major
    return 'Lightroom ' .. lrVerMajor
end



--- Check if platform (OS) is supported, and if version of Lightroom is supported. Offer user opportunity to bail if not.
--
--  @usage      Returns nothing - presents dialog if plugin lacks pre-requisite support, and throws error if user opts not to continue.
--  @usage      It is intended that this be called WITHOUT being wrapped by an error handler, so error causes true abortion.
--              <br>Init.lua is a good candidate...
--
function App:checkSupport()
    local op = Call:new{ name='check support', async=false, main=function( call )
        local is = self:isPlatformSupported()
        if is ~= nil then
            if is then
                -- good to go - be silent.
                -- dialog:showInfo( "Good to go..." )
                self:logInfo( "Platform support verified - certified for " .. self:getPlatformString() )
            else
                if dialog:isOk( str:fmt( "Plugin not officially supported on ^1, want to try your luck anyway?", self:getPlatformName() ) ) then
                    -- continue
                else
                    call:abort( self:getPlatformName() .. " platform not supported." )
                end
            end
        else
            if dialog:isOk( str:fmt( "Plugin author has not specified whether ^1 runs on ^2, want to try your luck anyway?", self:getPluginName(), self:getPlatformName() ) ) then
                -- continue
                self:logInfo( "Continuing without explicitly specified platform support..." )
            else
                call:abort( self:getPlatformName() .. " platform not supported." )
            end
        end
        is = self:isLrVersionSupported()
        if is ~= nil then
            if is then
                -- good to go - be silent.
                -- dialog:showInfo( "Good to go..." )
                self:logInfo( "Lightroom version support verified - certified for " .. self:getLrCompatibilityString() )
            else
                if dialog:isOk( str:fmt( "Plugin not officially supported on ^1, want to try your luck anyway?", self:getLrVersionName() ) ) then
                    -- continue
                else
                    call:abort( str:fmt( "Lightroom version ^1 not supported.", LrApplication.versionString() ) )
                end
            end
        else
            if dialog:isOk( str:fmt( "Plugin author has not specified whether ^1 runs on ^2, want to try your luck anyway?", self:getPluginName(), self:getLrVersionName() ) ) then
                -- continue
                self:logInfo( "Continuing without explicitly specified lightroom version support..." )
            else
                call:abort( str:fmt( "Lightroom version ^1 not supported.", LrApplication.versionString() ) )
            end
        end
    end }
    self:call( op )
    -- the following code depends on async=false.
    if op:isAborted() then
        LrErrors.throwUserError( op:getAbortMessage() )
    end
end



--- Returns string for displaying Platform & Lightroom compatibility.
--
--  <p>Typically this is used in the plugin manager for informational purposes only.
--  Info for program logic best obtained using other methods, since format returned
--  by this function is not guaranteed.</p>
--
--  @return         string: e.g. "Windows+Mac, Lr2 to Lr3"
--
function App:getCompatibilityString()

    local compatTbl = {}
    local platforms = self:getPlatformString()
    if str:is( platforms ) then
        compatTbl[#compatTbl + 1] = platforms
    end
    compatTbl[#compatTbl + 1] = self:getLrCompatibilityString() -- always includes standard stuff
    local compatStr = table.concat( compatTbl, ", " )
    return compatStr

end



--- Does debug trace action provided supporting object has been created, and master debug is enabled.
--
--  <p>Typically this is not called directly, but instead by way of the dbg function returned
--  by the class constructor or object registrar. Still, it is available to be called directly if desired.</p>
--
--  @usage      Pre-requisite: advanced debug enabled, and logger enabled (@2010-11-22 - the latter always is).
--  @usage      See advanced-debug class for more information.
--
function App:debugTrace(...)
    --if self:isAdvDbgLogOk() then -- debug object created and debug enabled and logr available.
    if self:isAdvDbgEna() then -- advanced debug enabled - probably redundent, since dbgr-pause only pauses when enabled, oh well.
        -- self.advDbg:debugTrace( name, id, info )
        Debug.pause(...)
    -- else deep-6.
    end
end



--- Output debug info for class if class enabled for debug.
--
--  @usage      Typically this is not called directly, but instead by way of the dbg function returned
--              by the class constructor or object registrar. Still, it is available to be called directly if desired.
--  @usage      Pre-requisite: advanced debug enabled, and logger enabled (@2010-11-22 - the latter always is).
--  @usage      See advanced-debug class for more information.
--
function App:classDebugTrace( name, ...)
    if self:isClassDebugEnabled( name ) then
        Debug.pause( name, ... )
    end
end



--- Determine if advanced debug support and logger enabled to go with.
--
--  @usage        Typical use for determining whether its worthwhile to embark on some advanced debug support activity.
--
--  @return       boolean: true iff advanced debug functionality is "all-systems-go".
--
function App:isAdvDbgLogOk() -- ###1
    return self:isAdvDbgEna() and self.logr
end



--- Determine if class-filtered debug mode is in effect, and class of executing method is specifically enabled.
--
--  <p>Typically not called directly, but indirectly by dbg function, although it can be called directly if desired...</p>
--  
--  @param      name        Full-class-name, or pseudo-class-name(if not a true class) as registered.
--
function App:isClassDebugEnabled( name )
    if self:isAdvDbgEna() then
        if self:getGlobalPref( 'classDebugEnable' ) then -- limitations are in effect
            local propKey = Object.classRegistry[ name ].propKey
            if propKey then
                return self:getGlobalPref( propKey )
            else
                return true -- default to enabled if object not registered for limitation.
            end
        else
            return true
        end
    else
        return false
    end
end



--- Determine if basic app-wide debug mode is in effect.
--      
--  <p>Synonymous with log-verbose.</p>
--
function App:isDebugEnabled()
    return self:getGlobalPref( 'logVerbose' )
end



--- Get property from info-lua.
--
--  @param      name     The name of the property to get.
--
function App:getInfo( name )

    return self.infoLua[name]

end



--- Logs a rudimentary stack trace (function name, source file, line number).
--
--  @usage      No-op when advanced debugging is disabled.
--      
function App:debugStackTrace()
    --if not self:isAdvDbgLogOk() then -- debug object created and debug enabled and logr available.
    if not self:isAdvDbgEna() then -- advanced debug enabled - now uses independent logger. this is probably redundent.
        return
    end
    -- self.advDbg:debugStackTrace( 3 ) -- skip level 1 (dbg-func) and level 2 (this func).
    Debug.stackTrace( 3 )
end



--- Get the value of the specified preference.
--      
--  @param      name        Preference property name (format: string without dots).
--
--  @usage      Preference may be a member of a named set, or the un-named set.
--  @usage      See Preferences class for more info.
--
function App:getPref( name )
    if not str:is( name ) then
        error( "Preference name key must be non-empty string." )
    end
    if self.prefMgr then
        return self.prefMgr:getPref( name )
    elseif prefs then
        return prefs[name]
    else
        error( "No prefs." )
    end
end 



--- Set the specified preference to the specified value.
--      
--  @param      name        Preference property name (format: string without dots).
--  @param      value       Preference property value (type: simple - string, number, or boolean).
--
--  @usage      Preference may be a member of a named set, or the un-named set.
--  @usage      See Preferences class for more info.
--
function App:setPref( name, value )
    if not str:is( name ) then
        error( "Preference name key must be non-empty string." )
    end
    if self.prefMgr then
        self.prefMgr:setPref( name, value )
    elseif prefs then
        prefs[name] = value
    else
        error( "No prefs." )
    end
end 



--- Make sure support preference is initialized.
--
--  <p>Because of the way all this pref/prop stuff works,
--  uninitialized prefs can be a problem, since they are
--  saved into props via pairs() function that won't recognize
--  nil items, thus items that should be blanked, may retain
--  bogus values.</p>
--      
--  @usage      Pref value set to default only if nil.</p>
--      
--  @usage      Make sure init-props is being called to init the props
--              from the prefs afterward.
--
function App:initPref( name, default )
    if not str:is( name ) then
        error( "Preference name key must be non-empty string." )
    end
    if self.prefMgr then
        self.prefMgr:initPref( name, default )
    elseif prefs then
        if prefs[name] == nil then
            prefs[name] = default
        end
    else
        error( "No prefs." )
    end
end 



--- Delete preference preset.
--
--  @param props - get re-loaded from defaults, or if default set is being "deleted" (reset), then they're reloaded from saved default values.
--
--  @usage which is governed by global preset name pref.
--
function App:deletePrefPreset( props )
    self.prefMgr:deletePreset( props )
end



--- Log a simple key/value table.
--      
--  @usage      *** Deprecated - use Debug function instead.
--  @usage      No-op unless advanced debug enabled.
--  @usage      Does not re-curse.
--      
function App:logTable( t ) -- indentation would be nice ###3. - Presently does not support table recursion.
    self:logWarning( "app:logTable is deprecated - please use debug function instead." )
    if not self:isAdvDbgLogOk() then
        return
    end
    if t == nil then
        self:logInfo( "nil" )
        return
    end    
    for k,v in pairs( t ) do
        self:logInfo( "key: " .. str:to( k ) .. ", value: " .. str:to( v ) )
    end
end



--- Log any lua variable, including complex tables with cross links. - debug only
--      
--  <p>It could use a little primping, but it has served my purpose so I'm moving on.</p>
--
--  @usage          *** Deprecated - please use Debug function instead.
--  @usage          Can not be used to log _G, everything else thrown at it so far has worked.
--  @usage          Example: app:logObject( someTable )
--      
function App:logObject( t )
    self:logWarning( "app:logObject is deprecated - please use Debug function instead." )
    --if not self:isAdvDbgLogOk() then
    --    return
    --end
    if self:isAdvDbgEna() then
        --self.advDbg:logObject( t, 0 )
        Debug.pp( t ) -- test this
    end
end



--- Log an observable property table. - debug only
--      
--  @usage          No-op unless advanced debug logging is enabled.
--
function App:logPropertyTable( t, name )
    if not self:isAdvDbgLogOk() then
        return
    end
    if t == nil then
        Debug.logn( "property table is nil" )
        return
    end
    if t.pairs == nil then
        Debug.logn( str:to( name ) .. " is not a property table" )
        return
    end
    for k,v in t:pairs() do
        Debug.logn( k , " = ", v )
    end
end



--- Send unmodified keystrokes to lightroom.
--
--  <p>Unmodified meaning not enhanced by Ctrl/Cmd/Option/Alt/Shift...</p>
--      
--  @param      text        string: e.g. "p" or "u", maybe "g"...
--      
--  @usage      Platform agnostic (os specific object does the right thing).
--  @usage      Direct keystrokes at Lightroom proper, NOT dialog boxes, nor metadata fields, ...
--
--  @return     status(boolean): true iff command to send keys executed without an error.
--  @return     message(string): if status successful: the command issued, else error message (which includes command issued).
--
function App:sendKeys( text )
    return self.os:sendUnmodifiedKeys( text )
end



--- Send windows modified keystrokes to lightroom in AHK encoded format.
--      
--  @param      keys    i.e. mash the modifiers together (any order, case sensitive), followed by a dash, followed by the keystrokes mashed together (order matters, but case does not).
--  @param      noYield I've found, more times than not, a yield helps the keystrokes take effect. If yielding after sending the keys is causing more harm than good, set this arg to true.
--
--  @usage      e.g. '{Ctrl Down}s{Ctrl Up}' - note: {Ctrl}s doesn't cut it - probably whats wrong with vbs/powershell versions.
--  @usage      Direct keystrokes at Lightroom proper, NOT dialog boxes, nor metadata fields, ...
--      
--  @return     status(boolean): true iff command to send keys executed without an error.
--  @return     message(string): if status successful: the command issued, else error message (which includes command issued).
--
function App:sendWinAhkKeys( keys, noYield )
    if WIN_ENV then
        local s, m = self.os:sendUnmodifiedKeys( keys ) -- all keystrokes go through ahk.exe file now.
        if not noYield then
            LrTasks.yield()
        end
        return s, m
    else
        error( "Don't send windows keys on mac." )
    end
end



--  Could have emulated ahk format until ahk works well enough on Mac.
--  For now, plugin author is tasked with issuing two different sequences of things
--  depending on platform.
--      
--- Send mac modified keystrokes to lightroom, in proprietary encoded format as follows:
--      
--  @param      keys    i.e. mash the modifiers together (any order, case sensitive), followed by a dash, followed by the keystrokes mashed together (order matters, but case does not).
--
--  @usage      e.g. 'CmdOptionCtrlShift-FS'
--  @usage      Direct keystrokes at Lightroom proper, NOT dialog boxes, nor metadata fields, ...
--
--  @return     status(boolean): true iff command to send keys executed without an error.
--  @return     message(string): if status successful: the command issued, else error message (which includes command issued).
--
function App:sendMacEncKeys( keys )
    if MAC_ENV then
        return self.os:sendModifiedKeys( keys )
    else
        error( "Don't send mac keys on windows." )
    end
end



--- Checks for new version of plugin to download.
--
--  @param      autoMode        (boolean) set true if its an auto-check-upon-startup mode, so user isn't bothered by version up-2-date message.
--
--  @usage      Requires global xmlRpc object constructed with xml-rpc service URL.
--  @usage      Does not return anything - presents dialog if appropriate...
--
function App:checkForUpdate( autoMode )
    self:call( Call:new{ name = 'Check for Update', async=true, main=function( call )
        local id = self:getPluginId()
        local status, xml, values = xmlRpc:sendAndReceive( "updateCheck", { { type='string', value=id } }, 5 )
        if status then
            -- dbg( "good: ", xml )
            local currVer = self:getVersionString()
            assert( currVer, "no ver" )
            assert( #values == 2, "wrong number of return values" )
            assert( values[1].type == 'string' )
            assert( values[2].type == 'string' )
            local latest = values[1].value
            local download = values[2].value
            if not str:is( download ) then
                download = self:getPluginUrl()
            end
            local name = self:getPluginName()
            if currVer ~= latest then
                -- dbg( "new ver: ", str:format( "^1 from ^2", latest, download ) )
                if dialog:isOk( str:fmt( "There is a newer version of ^1 (current version is ^2).\n \nNewest version is ^3 - click 'OK' to download.", name, currVer, latest ) ) then
                    LrHttp.openUrlInBrowser( download )
                end
            elseif not autoMode then
                dialog:showInfo( str:fmt( "^1 is up to date at version: ^2", name, currVer ) )
            else
                self:logInfo( str:fmt( "Check for update result: ^1 is up to date at version: ^2", name, currVer ) )
            end
        else
            dialog:showInfo( str:fmt( "RPC Server Fault, fault-code: ^1, fault-string: ^2", str:to( values.faultCode ), str:to( values.faultString ) ) )
        end
    end } )
end



--- Sleep unless shutdown.
--
--  @usage      Called by background tasks primarily, to sleep in 100 msec increments, checking shutdown flag each increment.
--              <br>Returns when time elapsed or shutdown flag set.
-- 
function App:sleepUnlessShutdown( time )
    local startTime = LrDate.currentTime()
    while not shutdown and (LrDate.currentTime() - startTime < time) do
        LrTasks.sleep( .1 )
    end
    return
end



--- Asserts (synchronous) initialization is complete.
--
--  @usage Call at end of plugin's Init.lua module.
--
--  @usage Dumps declared globals to debug log, if advanced debug enabled.
--
function App:initDone()

    --self._initDone = true
    if not self:isAdvDbgEna() then return end
    
    Debug.logn( "Globals (declared):" )
    local g = getmetatable( _G ).__declared or {}
    local c = 0
    for k, v in tab:sortedPairs( g ) do
        local value = gbl:getValue( k )
        local className
        if value ~= nil and type( value ) == 'table' and value.getFullClassName then
            className = value:getFullClassName()
            if className == k then
                className = 'Class'
            end
        else
            className = type( value )
        end
        Debug.logn( str:to( k ), str:to( '(' .. className .. ')' ) )
        c = c + 1
    end
    Debug.logn( "Total:" .. c, '\n' )
    Debug.logn( "Undeclared globals:" )
    local c2 = 0
    for k, v in tab:sortedPairs( _G ) do
        if not g[k] then
            Debug.logn( str:to( k ) )
            c2 = c2 + 1
        end
    end
    
    Debug.logn( "Total undeclared globals:" .. c2, '\n' )

    if self:isVerbose() then
        local globalsByFile = Require.newGlobals() -- now cleared.
        Debug.logn( "Global details by file: ", Debug.pp( globalsByFile ) )
    end
    
end



--- Open debug log in default app for viewing.
--
--  @usage wrapped internally
--
function App:showDebugLog()
    app:call( Call:new { name='Show Debug Log', async=false, main=function( call )
        local logFile = Debug.getLogFilePath()
        if fso:existsAsFile( logFile ) then
            self:openFileInDefaultApp( logFile )
        else
            self:showInfo( "No debug log file: " .. logFile )
        end
    end } )
end



--- Clear debug log by moving to trash.
--
--  @usage wrapped internally
--
function App:clearDebugLog()
    app:call( Call:new { name='Clear Debug Log', async=false, main=function( call )
        local logFile = Debug.getLogFilePath()
        if fso:existsAsFile( logFile ) then
            local s, m = fso:moveToTrash( logFile )
            if s then
                self:showInfo( "Debug log cleared." )
            else
                self:showError( m )
            end
        else
            self:showInfo( "No debug log file: " .. logFile )
        end
    end } )
end



return App
