--[[
        Background.lua
        
        Background task - designed to be extended.
        
        Instructions:
        
            - Extend this background class to do something useful.
              - Override init method to do special initialization, if desired.
              - Override process method to do special processing.
            - Create (extended) background object and start background task in init.lua, perhaps conditioned by pref.
--]]

local Background, dbg = Object:newClass{ className = 'Background' }



--- Constructor for extending class.
--
function Background:newClass( t )
    return Object.newClass( self, t )
end



--- Constructor for new instance.
--
--  @param      t       initialization table, including:
--                      <br>interval in seconds (default is 1 second)
--                      <br>minInitTime - Default is 10, but recommend setting to 15 or 20 - so user has time to inspect startups in progress corner, or set to zero to suppress init progress indicator altogether.
--
function Background:new( t )

    local o = Object.new( self, t )
    o.interval = o.interval or 1 -- polling interval
    o.initStatus = false
    o.done = false
    o.minInitTime = o.minInitTime or 10
    o.state = 'idle'
    return o
    
end



--- Background init function.
--
--  @param      call object - usually not needed, but its got the name, and context... just in case.
--
--  @usage      override to do special initialization, if desired.
--              <br>Try not to throw errors in init, but instead set initStatus to true or false depending on whether successful or not.
--              <br>no need to call this method from extended class, yet.
--
--  @usage      if init is lengthy, check for shutdown sometimes and abort(return) if set - initStatus a dont care in that case.
--
function Background:init( call )
    self.initStatus = true
end



--- Presents modal dialog that suspends background task while its up.
--
--  @usage Typically called from a running background task.
--
function Background:presentModalDialog( args )
    self:pause()
    local answer = LrDialogs.presentModalDialog( args )
    self:continue()
    return answer
end



--- Wait for asynchronous initialization to complete.
--
--  @param tmo - initial timeout in seconds - default is half second.
--  @param ival - recheck interval if not finished initializing upon initial timeout - return immediately and do not prompt user if nil or zero. Ignored if tmo is zero.
--
--  @usage Untested @2011-01-08 ###2
--
--  @return status - true iff init completed successfully.
--  @return explanation if init failed.
-- 
function Background:waitForInit( tmo, ival )

    tmo = tmo or .5
    if self.initStatus then
        return true
    elseif tmo == 0 then
        return false, "initialization incomplete"
    else -- wait loop
        ival = ival or 0
    end
    local time = LrDate.currentTime() + tmo
    repeat
        LrTasks.sleep( .1 )
        if self.initStatus then
            break
        end    
        if LrDate.currentTime() > time then -- either initial or interval timeout
            if ival > 0 then
                if app:isOk( str:fmt( "^1 is not ready yet. Wait another ^2 seconds?", app:getAppName(), ival ) ) then
                    time = LrDate.currentTime() + ival
                else
                    return false, "wait for initialization was canceled"
                end
            else
                return false, "initialization timed out"
            end
        -- else keep checking.
        end
    until false
    return true -- init complete.

end



--- Background process function.
--
--  @param      call object - usually not needed, but its got the name, and context... just in case.
--
function Background:process( call )
    LrDialogs.message( "background " .. tostring( _G ) )
end



--- Executes the specified command via the OS command shell.
--
--  @param              
--
--  @usage              
--
function Background:start()
    app:call( Call:new { name='Background Task', async=true, guard=App.guardSilent, main=function( call )
        self.state = 'starting'
        local scope = LrProgressScope {
            title = app:getAppName() .. " Starting Up",
            caption = "Please wait...",
            functionContext = call.context,
        }
        local startTime = LrDate.currentTime()
        LrTasks.sleep( .1 ) -- without this ya cant see the startup progress bar.
        self:init( call )
        if self.initStatus then
            while not self.done and not shutdown and not scope:isCanceled() and (LrDate.currentTime() < (startTime + self.minInitTime)) do
                LrTasks.sleep( .2 ) -- coarse sleep timer OK for responding to status change while initializing.
            end
            scope:done()
        else
            scope:setCaption( "Initialization failed." )
            repeat
                app:sleepUnlessShutdown( .5 ) -- coarse is ok - takes a bit for cancellation to be acknowleged anyway.
                if scope:isCanceled() then
                    error( "Unable to initialize background task." )
                elseif shutdown then
                    scope:done()
                end
            until scope:isDone()
        end
        if self.initStatus then
            app:logInfo( "Asynchronous initialization completed successfully." )
            self.state = 'running'
            while not shutdown and not self.done do
                app:sleepUnlessShutdown( self.interval )
                if not shutdown and enabled then -- plugin enabled
                    if self.state == 'pausing' then
                        self.state = 'paused'
                    elseif self.state == 'paused' then
                        -- dont do anything
                    else -- if not pausing or paused, then run if possible...
                        -- assert self.state == 'running
                        -- self:process( call )
                        local status, message = LrTasks.pcall( self.process, self, call )
                        if status then
                            -- dbg( "bg ok" )
                            -- app:sleepUnlessShutdown( 1 )
                        else
                            app:logError( "Error in background task, message: " .. str:to( message ) )
                            if app:isVerbose() then -- this error often occurs when a photo is deleted: best to not bother user in normal mode.
                                app:showError( "Error in background task, message: " .. str:to( message ) )
                            end
                            app:sleepUnlessShutdown( 3 ) -- institute an error hold-off, so as not to overrun the logger...
                        end
                    end
                -- else hold until enabled.
                end
            end
        end
    end, finale=function( call, status, message )
        self.state = 'idle'
        if status then
            app:logInfo( "Background/init task terminated without error." )
        else
            app:logError( "Background task aborted due to error: " .. ( message or 'nil' ) )
            app:showError( "Background task aborted due to error: " .. ( message or 'nil' ) )
        end
    end } )
end



function Background:quit()
    self.done = true
end



--- Pause background task.
--
--  @usage you must continue in finale method of call or service, lest background task dies forever.
--
function Background:pause()
    if self.state ~= 'running' then
        return -- lets not get hung up trying to pause something that is not even running.
    end
    self.state = 'pausing'
    local count = 100 -- 10 second timeout.
    while not shutdown and not self.state == 'paused' and count > 0 do
        LrTasks.sleep( .1 )
        count = count - 1
    end
    if count == 0 then
        app:logError( "Unable to pause background task - motoring on..." )
    end
end



--- Continue background task.
--
--  @usage No-op if not paused.
--
function Background:continue()
    if self.state == 'pausing' or self.state == 'paused' then
        self.state = 'running'
    -- else leave state alone.
    end
end



--- Wait for background task to finish.
--
--  @usage Dont call unless you know its on its way out, e.g. shutdown for reload.
--
function Background:waitForIdle()
    while self.state ~= 'idle' do
        LrTasks.sleep( .1 )
    end
end



return Background