--[[
        Preference Manager
        
        Supports name preference sets that may or may not be supplemented by a preference config file.
--]]

local Preferences, dbg = Object:newClass{ className = 'Preferences' }



--- Constructor for extending class.
--
function Preferences:newClass( t )
    return Object.newClass( self, t )
end



--- Constructs a new preference manager.
--      
--  <p>Installation procedure is going to have to be smart enough to deal with pre-existing directory upgrade.</p>
--
--  <p>This object manages named preference sets. Exclude and you just have the reglar set of unnamed (un-prefixed) prefs...</p>
--
--  <p>Param Table In:<blockquote>
--          - name(id): set name. if missing, then default set.<br>
--          - file-essential boolean.</blockquote></p>
--                          
--  <p>Object Table Out:<blockquote>
--          - friendlyName: same as name/id except for default.<br>
--          - file (path)<br>
--          - prefs (name-val table)</blockquote></p>
--      
--  @param      t       input parameter table.
--
--  @usage              Subdirectory for supplemental files is 'Preferences' in plugin directory.
--  @usage              See app class pref methods for more info.
--
--  @return             Preference manager object.
--
function Preferences:new( t )

    local o = Object.new( self, t )
    
    o.file = nil -- path to most recently loaded preference backing file.
    o.filePrefs = nil -- return table read from preference backing file.
    o.prefDir = LrPathUtils.child( _PLUGIN.path, 'Preferences' )
    o.dfltFile = LrPathUtils.child( o.prefDir, 'Default.lua' )
    o.backing = fso:existsAsFile( o.dfltFile ) -- deleting default file is disallowed.
    o.file = ''
    o.dfltProps = {}
    o.glblDfltProps = {}
    
    return o
end        



--- Create a new named set, and load properties with initial values.
--
function Preferences:createPreset( props )
    local presetName = self:getPresetName()
    if presetName == 'Default' then
        error( "Check for default set is external." )
    end
    self:saveProps( props ) -- prop driven, non-nil props are saved in prefs - set on its way out.
    if self.backing then
        local file = LrPathUtils.child( self.prefDir, presetName .. ".lua" )
        if not fso:existsAsFile( file ) then -- backing file is absent.
            if fso:existsAsFile( self.dfltFile ) then
                local s,m = fso:copyFile( self.dfltFile, file )
                if s then
                    self:loadPrefFile( file )
                    if self.filePrefs then
                        if dialog:isOk( str:format( "Preference support file created for ^1 - edit now?", presetName ) ) then
                            app:openFileInDefaultApp( self.file )
                        --else
                        end
                    end
                else
                    error( m )
                end
            else
                dialog:showError( "Default preference file is missing: " .. self.dfltFile )
            end
        else
            self:loadPrefFile( file )
            if self.filePrefs then
                local answer = dialog:showInfo( str:format( "^1 settings are backed by lua preference file: ^2 - edit now?", presetName, self.file ), "NamedPrefBackPrompt", {{label="Edit Now",verb='yes'},{label="Not Now",verb='no' }} )
                if answer == 'yes' then
                    app:openFileInDefaultApp( file )
                end
            end
        end
    end
    self:loadProps( props )
end



--- Get preference preset name.
--
--  @param friendly (return "Un-named" instead of 'Default')
--
--  @return name if not nil, else 'Default'.
--
function Preferences:getPresetName( friendly )
    local presetName
    if prefs._global_presetName ~= nil then
        presetName = LrStringUtils.trimWhitespace( prefs._global_presetName ) -- I would have expected UI to trim but it does not.
    end
    if str:is( presetName ) then
        return presetName
    elseif friendly then
        return '"Un-named"'
    else
        return 'Default'
    end
end



--- Switch to named or unamed preference set.
--
function Preferences:switchPreset( props )
    -- self:saveProps( props )
    local presetName = self:getPresetName()
    if self.backing then
        local file
        file = LrPathUtils.child( self.prefDir, presetName .. ".lua" )
        if not fso:existsAsFile( file ) then -- backing file is absent - note: we are switching to an already existing set,
            -- so if backing is supported, the file should be there.
            if presetName == 'Default' then
                error( 'Default preference support file has disappeared: ' .. str:to( self.dfltFile ) )
            end
            if dialog:isOk( str:format( "Preference file supporting '^1' settings has disappeared - create a new one?", presetName ) ) then
                if fso:existsAsFile( self.dfltFile ) then
                    local s,m = fso:copyFile( self.dfltFile, file )
                    if s then
                        self:loadPrefFile( file ) -- load props used to do this.
                        if self.filePrefs then
                            if dialog:isOk( "Preferences support file created anew - edit now?" ) then
                                app:openFileInDefaultApp( self.file )
                            --else its user's responsibility to edit later, or not.
                            end
                        else
                            error( "Preference support file won't load: " .. self.file )
                        end
                    else
                        error( m )
                    end
                else
                    dialog:showError( "Default preference file is missing: " .. self.dfltFile )
                end
            else
                app:logWarning( "Best find that file (" .. file .. "), since preference support file is required for this plugin." )
            end
        else
            self:loadPrefFile( file ) -- load props used to do this
            app:logInfo( str:format( "Switched to pref set ^1 backed by ^2", presetName, file ) )
        end
    else
        dbg( "No backing" )
    end
    if props then
        self:loadProps( props )
    end
    if presetName == 'Default' then
        prefs._global_presetName = nil
    end
end



--- Determine if preference file backing is supported by this plugin.
--
function Preferences:isBackedByFile()
    return self.backing
end



--- Gets path to preference support file.
--
--  @return full path
--  @return filename
--
function Preferences:getPrefSupportFile()
    local presetName = self:getPresetName()
    local name = presetName .. ".lua"
    return self.file, name
end



--- Load preference "backing" file.
--
--  <p>Preferences not in lr-pref table, are looked for in preference backing file, if available.</p>
--
--  @param file     The path to the file.
--
function Preferences:loadPrefFile( file )

    self.file = file
    local status, prefTbl = pcall( dofile, file )
    if status and prefTbl and type( prefTbl ) == 'table' then
        app:logInfo( "Using preferences ala file: " .. self.file )
        self.filePrefs = prefTbl
    else
        app:logInfo( "No pref support loaded from " .. self.file, App.verbose )
        self.filePrefs = nil
    end
    
end



--  Translates a simple property name to its equivalent name-prefixed pref key,
--      
--  <p>If active name is null, then prop-name is pref-key - assures compatibility with no-preference module configuration.</p>
--
--  @usage      Reminder: not public.
--
--  @return     key for pref index.
--
function Preferences:_getPrefKey( propName )
    local presetName = self:getPresetName()
    return presetName .. '__' .. propName
end



--- Get global preference value.
--
--  @usage key is name prefixed by _global_ in the interest of keeping a clear separation,
--  <br>between managed preference globals and unmanaged, and also preset preferences.
--
--  @return the value - may be nil.
--
function Preferences:getGlobalPref( name )
    return prefs['_global_'..name]
end



--- Get actual preference key corresponding to managed global preference name.
--
--  @return key suitable for binding.
--
function Preferences:getGlobalKey( name )
    return '_global_' .. name
end



--- Set global preference value.
--
--  @usage key is name prefixed by _global_ in the interest of keeping a clear separation,
--  <br>between managed preference globals and unmanaged, and also preset preferences.
--
function Preferences:setGlobalPref( name, val )
    prefs['_global_'..name] = val
end



--- Sets global preference based on property name.
--      
--  <p>Named or unamed.</p>
--
--  @usage      like all preference methods, this method is wrapped by app object - see App class for more info.
--
function Preferences:setPref( name, value )
    local key = self:_getPrefKey( name )
    if prefs[name] then
        dbg( "property being set to prefs already exists without prefix: ", name )
    end
    prefs[key] = value
end



--- Sets preference based on property name.
--      
--  <p>Named or unamed.</p>
--  <p>Is should not be necessary to init props to match here, provided props are loaded from prefs afterward.</p>
--      
--  @usage      Like all preference methods, this method is wrapped by app object - see App class for more info.
--
function Preferences:initPref( name, dflt )
    local key = self:_getPrefKey( name )
    if prefs[key] == nil then
        prefs[key] = dflt -- so pref is not nil.
    end
    self.dfltProps[name] = dflt
end



--- Initialize global preference value.
--      
--  @usage      Like all preference methods, this method is wrapped by app object - see App class for more info.
--
function Preferences:initGlobalPref( name, dflt )
    local key = self:getGlobalKey( name )
    if prefs[key] == nil then
        prefs[key] = dflt
    end
    self.glblDfltProps[key] = dflt
end



--- Gets pref value corresponding to prop name.
--      
--  <p>Named or unamed.</p>
--
--  @usage      Like all preference methods, this method is wrapped by app object - see App class for more info.
--
function Preferences:getPref( propName )
    local prefKey = self:_getPrefKey( propName )
    local value = prefs[prefKey]
    if value ~= nil then
        return value
    end
    if self.filePrefs then -- file backed value.
        value = self.filePrefs[propName]
    -- else value still nil
    end
    return value
end



--- Load properties from preset.
--
--  <p>Default set is handled like any other: properties are loaded whether set is registered or not.</p>
--
--  @usage      Like all preference methods, this method is wrapped by app object - see App class for more info.
--
function Preferences:loadProps( props )
    local presetName = self:getPresetName()
    if presetName ~= 'Default' then
        if prefs['preset__' .. presetName] == nil then
            dbg( "Loading properties from unregistered (non-default) set named ", presetName )
        end
    end
    local prefix = presetName .. '__' -- must match get-pref-key.
    local pos = prefix:len() + 1
    for k,v in prefs:pairs() do
        if str:isStartingWith( k, prefix ) then
            local propName = k:sub( pos )
            dbg( "load prop: ", str:format( "prop-name: ^1, val: ^2, from pref-key: ^3", propName, str:to( v ), k ) )
            props[propName] = v
        else
            -- dbg( "skip load prop: ", k )
        end
    end
end



--- Save propertiesavings into named or unamed set.
--      
--  <p>If named, sets 'name-existing' indicator into prefs.</p>
--
--  @usage      Like all preference methods, this method is wrapped by app object - see App class for more info.
--
function Preferences:saveProps( props )
    assert( props ~= prefs, "props are prefs" )
    local presetName = self:getPresetName()
    for k,v in props:pairs() do
        if k:find( '_global_' ) then
            dbg( 'global prop should not be saved' )
        else
            self:setPref( k, v )
        end
    end
    dbg( "registering saved preset: ", "preset__" .. presetName )
    prefs["preset__" .. presetName] = true
end



--- Checks if specified named set exists.
--
--  @usage      @2010-11-22 - only called within pref mngr proper.
--
function Preferences:isPresetExisting( setName )
    dbg( "checking if set exists: ", str:format( "nm: ^1, val: ^2", "preset__" .. setName, str:to( prefs["preset__" .. setName] ) ) )
    return prefs["preset__" .. setName]
end



--- Delete active named set.
--      
--  @param      props       Properties to load from some other set (presently the default/un-named set) once present set is deleted.
--
--  @usage      Throws error if active set is unamed, so check first.
--
function Preferences:deletePreset( props )
    local presetName = self:getPresetName()
    local ok
    if presetName == 'Default' then
        ok = dialog:isOk( str:fmt( "Reset un-named settings?" ) )
    else
        ok = dialog:isOk( str:format( "Delete ^1 Settings?", presetName ) )
    end
    if ok then
        self:_deletePreset( props ) -- name implied.
    end
end



--- Load defaults into properties.
--
--  @usage defaults come from init-pref calls.
--
function Preferences:loadDefaults( props )
    local presetName = self:getPresetName()
    local prefix = presetName .. '__'
    local pos = prefix:len() + 1
    for k,v in prefs:pairs() do
        if str:isStartingWith( k, prefix ) then
            local propName = k:sub( pos )
            local value = self.dfltProps[propName]
            dbg( "loading default: ", str:format( "prop-name: ^1, val: ^2, pref-key: ^3", propName, str:to( value ), k ) )
            prefs[k] = value
            props[propName] = value -- could just load-props afterward, but might as well get it while I'm here...
        elseif app:isVerbose() then
            dbg( "not loading default: ", k )
        end
    end
end



--- Load defaults into properties.
--
--  @usage defaults come from init-pref calls.
--
function Preferences:loadGlobalDefaults()
    local prefix = '_global_'
    local pos = prefix:len() + 1
    for k,v in prefs:pairs() do
        if str:isStartingWith( k, prefix ) then
            -- local propName = k:sub( pos )
            local value = self.glblDfltProps[k]
            dbg( "loading global default: ", str:format( "key: ^1, val: ^2", k, str:to( value ) ) )
            prefs[k] = value
            -- props[propName] = value -- could just load-props afterward, but might as well get it while I'm here...
        elseif app:isVerbose() then
            dbg( "not loading global default: ", k )
        end
    end
end



--  Delete active named set.
--      
--  @param      props       Properties to load from some other set (presently the default/un-named set) once present set is deleted.
--
--  @usage      Throws error if active set is unamed, so check first.
--
function Preferences:_deletePreset( props )
    local presetName = self:getPresetName()
    local prefix = presetName .. '__'
    local pos = prefix:len() + 1
    for k,v in prefs:pairs() do
        if str:isStartingWith( k, prefix ) then
            local propName = k:sub( pos )
            dbg( "del: ", str:format( "prop-name: ^1, val: ^2", propName, str:to( v ) ) )
            if presetName == 'Default' then
                prefs[k] = self.dfltProps[propName]
            else
                prefs[k] = nil
            end
        else
            dbg( "not deleting: ", k )
        end
    end
    if presetName ~= 'Default' then
        local file = LrPathUtils.child( self.prefDir, presetName .. ".lua" )
        if fso:existsAsFile( file ) then
            if dialog:isOk( str:format( "Delete preference support file as well: ^1", file ) ) then
                local s,m = fso:moveToTrash( file )
                if s then
                    app:showInfo( "Moved to trash: " .. file )
                else
                    app:showError( "Unable to delete file: " .. file )
                end
            end
        end
        dbg( "Unregistering preset: ", presetName )
        prefs["preset__" .. presetName] = nil
    end
    prefs._global_presetName = nil
    self:loadProps( props )
    if presetName == 'Default' then
        dialog:showInfo( 'Unnamed settings have been reset.' )
    end
end



--- Return iterator that feeds k,v pairs back to the calling context sorted according to the specified sort function.
--      
--  @param           sortFunc       May be nil, in which case default sort order is employed (alphabetical).
--      
--  @return          Iterator function.
--
function Preferences:sortedPairs( sortFunc )
    local a = {}
    for k in prefs:pairs() do
        a[#a + 1] = k
    end
    table.sort( a, sortFunc )
    local i = 0
    return function()
        i = i + 1
        return a[i], prefs[a[i]]
    end
end



--- Gets list of saved (registered) presets.
--      
--  @return    Array of strings suitable for combo box.
--
function Preferences:getPresetItems()
    local items = { '"Un-named"' }
    for k,v in self:sortedPairs() do
        if str:isStartingWith( k, "preset__" ) then
            local set = k:sub( 9 )
            if set ~= 'Default' then
                items[#items + 1] = set
            else
                dbg( 'Pref mgr thought Default was not gonna be registered.' )
            end
        end
    end
    return items
end



return Preferences